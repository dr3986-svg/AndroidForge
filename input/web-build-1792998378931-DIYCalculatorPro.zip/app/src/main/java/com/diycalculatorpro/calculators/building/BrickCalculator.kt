package com.diycalculatorpro.calculators.building

import com.diycalculatorpro.R
import com.diycalculatorpro.engine.CalcResult
import com.diycalculatorpro.engine.CalculatorEngine
import com.diycalculatorpro.engine.ChoiceField
import com.diycalculatorpro.engine.ChoiceOption
import com.diycalculatorpro.engine.EngineContext
import com.diycalculatorpro.engine.NumberField
import com.diycalculatorpro.engine.ResultRow
import com.diycalculatorpro.engine.Units
import com.diycalculatorpro.engine.Validate
import com.diycalculatorpro.engine.Values
import kotlin.math.ceil

/**
 * Brickwork quantity and mortar.
 *
 * Brick counts per square metre are derived from the nominal brick size plus
 * the mortar joint, so changing the joint thickness changes the quantity.
 */
object BrickCalculator : CalculatorEngine {

    const val F_LENGTH = "length"
    const val F_HEIGHT = "height"
    const val F_THICKNESS = "thickness"
    const val F_JOINT = "joint"
    const val F_BRICK = "brick"
    const val F_MORTAR = "mortar"

    const val BRICK_UK = "uk"
    const val BRICK_US = "us"
    const val BRICK_LIGHT = "light"

    const val MORTAR_1_3 = "1:3"
    const val MORTAR_1_4 = "1:4"
    const val MORTAR_1_5 = "1:5"

    /** Brick format: length, height, thickness in mm, and mortar per m². */
    private data class BrickFormat(val length: Double, val height: Double, val thickness: Double)

    private val formats = mapOf(
        BRICK_UK to BrickFormat(215.0, 102.5, 65.0),
        BRICK_US to BrickFormat(215.0, 102.5, 65.0),
        BRICK_LIGHT to BrickFormat(440.0, 215.0, 100.0)
    )

    /** Mortar volume in m³ needed per m² of brickwork. */
    private val mortarPerM2 = mapOf(
        BRICK_UK to 0.0225,
        BRICK_US to 0.0225,
        BRICK_LIGHT to 0.0100
    )

    /** Cement in kg per m³ of finished mortar, and sand in kg per m³. */
    private val mixCementKg = mapOf(
        MORTAR_1_3 to 300.0,
        MORTAR_1_4 to 230.0,
        MORTAR_1_5 to 192.0
    )
    private val mixSandKg = mapOf(
        MORTAR_1_3 to 1200.0,
        MORTAR_1_4 to 920.0,
        MORTAR_1_5 to 768.0
    )

    val fields = listOf(
        NumberField(
            id = F_LENGTH,
            labelRes = R.string.f_building_brick_length,
            unitOptions = listOf(Units.M, Units.MM, Units.CM, Units.FOOT),
            defaultUnitId = Units.M.id,
            allowZero = false
        ),
        NumberField(
            id = F_HEIGHT,
            labelRes = R.string.f_building_brick_height,
            unitOptions = listOf(Units.M, Units.MM, Units.CM, Units.FOOT),
            defaultUnitId = Units.M.id,
            allowZero = false
        ),
        NumberField(
            id = F_THICKNESS,
            labelRes = R.string.f_building_brick_thickness,
            unitOptions = listOf(Units.MM, Units.CM, Units.INCH),
            defaultUnitId = Units.MM.id,
            allowZero = false
        ),
        NumberField(
            id = F_JOINT,
            labelRes = R.string.f_building_brick_joint,
            unitOptions = listOf(Units.MM, Units.CM),
            defaultUnitId = Units.MM.id,
            min = 0.0,
            max = 30.0,
            helperRes = R.string.f_building_brick_joint_helper
        ),
        ChoiceField(
            id = F_BRICK,
            labelRes = R.string.f_building_brick_brick,
            options = listOf(
                ChoiceOption(BRICK_UK, R.string.opt_brick_uk),
                ChoiceOption(BRICK_US, R.string.opt_brick_us),
                ChoiceOption(BRICK_LIGHT, R.string.opt_brick_light)
            ),
            defaultOptionId = BRICK_UK
        ),
        ChoiceField(
            id = F_MORTAR,
            labelRes = R.string.f_building_brick_mortar,
            options = listOf(
                ChoiceOption(MORTAR_1_3, R.string.opt_mortar_1_3),
                ChoiceOption(MORTAR_1_4, R.string.opt_mortar_1_4),
                ChoiceOption(MORTAR_1_5, R.string.opt_mortar_1_5)
            ),
            defaultOptionId = MORTAR_1_4
        )
    )

    private val lengthField = fields.filterIsInstance<NumberField>().first { it.id == F_LENGTH }
    private val heightField = fields.filterIsInstance<NumberField>().first { it.id == F_HEIGHT }
    private val thicknessField = fields.filterIsInstance<NumberField>().first { it.id == F_THICKNESS }
    private val jointField = fields.filterIsInstance<NumberField>().first { it.id == F_JOINT }

    override fun calculate(values: Values, ctx: EngineContext): CalcResult {
        Validate.requireFields(values, listOf(lengthField, heightField, thicknessField))
            ?.let { return it }

        val length = values.baseValue(lengthField) ?: 0.0
        val height = values.baseValue(heightField) ?: 0.0
        val thickness = values.baseValue(thicknessField) ?: 0.0
        val joint = values.baseValue(jointField) ?: 0.010

        if (length <= 0.0) return CalcResult.error(F_LENGTH, Validate.ERR_POSITIVE)
        if (height <= 0.0) return CalcResult.error(F_HEIGHT, Validate.ERR_POSITIVE)
        if (thickness <= 0.0) return CalcResult.error(F_THICKNESS, Validate.ERR_POSITIVE)

        val brickId = values.choices[F_BRICK] ?: BRICK_UK
        val mortarId = values.choices[F_MORTAR] ?: MORTAR_1_4
        val format = formats[brickId] ?: formats.getValue(BRICK_UK)

        val area = length * height

        // A header course needs the brick length plus a joint per unit.
        val unitLength = format.length + joint * 1000.0
        val unitHeight = format.height + joint * 1000.0

        // Bricks per m² from the modular size.
        val unitLength = format.length + joint * 1000.0
        val unitHeight = format.height + joint * 1000.0
        val bricksPerM2Single = 1.0 / ((unitLength / 1000.0) * (unitHeight / 1000.0))

        // A thicker wall needs more wythes (skins) of bricks.
        val thicknessMm = thickness * 1000.0
        val wythes = ceil(thicknessMm / format.thickness).coerceAtLeast(1.0)
        val bricksPerM2 = bricksPerM2Single * wythes
        val bricks = ceil(area * bricksPerM2)

        val mortarVolume = area * (mortarPerM2[brickId] ?: 0.0225)
        val cementKg = mortarVolume * (mixCementKg[mortarId] ?: 230.0)
        val sandKg = mortarVolume * (mixSandKg[mortarId] ?: 920.0)
        val cementBags = ceil(cementKg / 25.0)
        val sandBags = ceil(sandKg / 25.0)

        val rows = mutableListOf(
            ResultRow(ctx.str(R.string.r_area), ctx.withUnit(area, Units.M2)),
            ResultRow(
                ctx.str(R.string.f_building_brick_count),
                "${ctx.trim(bricks, 0)} bricks",
                emphasise = true
            ),
            ResultRow(ctx.str(R.string.f_building_brick_per_m2), ctx.trim(bricksPerM2, 1)),
            ResultRow(ctx.str(R.string.f_building_brick_wythes), ctx.trim(wythes, 0)),
            ResultRow(
                ctx.str(R.string.f_building_brick_mortar_volume),
                ctx.withUnit(mortarVolume, Units.M3, 3)
            ),
            ResultRow(
                ctx.str(R.string.f_building_brick_cement),
                "${ctx.trim(cementBags, 0)} bags (${ctx.trim(cementKg, 0)} kg)"
            ),
            ResultRow(ctx.str(R.string.f_building_brick_sand), "${ctx.trim(sandBags, 0)} bags (${ctx.trim(sandKg, 0)} kg)")
        )

        val notes = mutableListOf<String>()
        notes += ctx.str(R.string.f_building_brick_note_order)

        return CalcResult(
            headline = "${ctx.trim(bricks, 0)} bricks",
            headlineLabel = ctx.str(R.string.f_building_brick_headline),
            rows = rows,
            notes = notes
        )
    }
}
