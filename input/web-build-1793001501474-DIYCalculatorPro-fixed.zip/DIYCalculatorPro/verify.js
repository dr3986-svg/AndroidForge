// Verifies that every R.<type>.<name> reference in Kotlin and XML resolves
// to a defined resource. Run with: node verify.js
const fs = require('fs');
const path = require('path');

const ROOT = '/data/data/com.termux/files/home/DIYCalculatorPro';
const APP = path.join(ROOT, 'app/src/main');
const SRC = path.join(APP, 'java');
const RES = path.join(APP, 'res');

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else out.push(p);
  }
  return out;
}

// ---- collect defined resources ----
const defined = { string: new Set(), drawable: new Set(), color: new Set(), id: new Set(), style: new Set(), dimen: new Set(), layout: new Set(), menu: new Set(), xml: new Set(), mipmap: new Set() };

for (const f of walk(RES)) {
  const rel = path.relative(RES, f);
  const parts = rel.split(path.sep);
  const typeDir = parts[0];
  const type = typeDir.replace(/-(v\d+|anydpi.*|night|port|land)$/, '').replace(/-.*$/, '');
  const base = path.basename(f);
  if (typeDir === 'values') {
    const xml = fs.readFileSync(f, 'utf8');
    for (const m of xml.matchAll(/<string\s+name="([^"]+)"/g)) defined.string.add(m[1]);
    for (const m of xml.matchAll(/<color\s+name="([^"]+)"/g)) defined.color.add(m[1]);
    for (const m of xml.matchAll(/<dimen\s+name="([^"]+)"/g)) defined.dimen.add(m[1]);
    for (const m of xml.matchAll(/<style\s+name="([^"]+)"/g)) defined.style.add(m[1]);
    for (const m of xml.matchAll(/<item\s+name="([^"]+)"\s+type="([^"]+)"/g)) {
      if (m[2] === 'id') defined.id.add(m[1]);
    }
  } else if (typeDir.startsWith('color')) {
    // A res/color file may be a <selector> (no name attr) or a <color> (has name).
    const xml = fs.readFileSync(f, 'utf8');
    for (const m of xml.matchAll(/<color\s+name="([^"]+)"/g)) defined.color.add(m[1]);
    // Selector files are referenced by their file name.
    defined.color.add(base.replace(/\.xml$/, ''));
  } else if (typeDir.startsWith('drawable')) {
    defined.drawable.add(base.replace(/\.xml$/, ''));
  } else if (typeDir.startsWith('mipmap')) {
    defined.mipmap.add(base.replace(/\.xml$/, ''));
  } else if (typeDir.startsWith('layout')) {
    defined.layout.add(base.replace(/\.xml$/, ''));
  } else if (typeDir.startsWith('menu')) {
    defined.menu.add(base.replace(/\.xml$/, ''));
  } else if (typeDir.startsWith('xml')) {
    defined.xml.add(base.replace(/\.xml$/, ''));
  }
}

// ---- collect references ----
const problems = [];

// Kotlin references
for (const f of walk(SRC)) {
  if (!f.endsWith('.kt')) continue;
  const src = fs.readFileSync(f, 'utf8');
  const rel = path.relative(ROOT, f);
  for (const m of src.matchAll(/\bR\.(string|drawable|color|layout|menu|mipmap|dimen|style|id)\.([A-Za-z_][A-Za-z0-9_]*)/g)) {
    const [, type, name] = m;
    if (type === 'id') continue; // ids are generated from layouts
    if (!defined[type] || !defined[type].has(name)) {
      problems.push(`${rel}: R.${type}.${name}  (no such ${type})`);
    }
  }
}

// XML @type/name references
for (const f of walk(RES)) {
  if (!f.endsWith('.xml')) continue;
  const src = fs.readFileSync(f, 'utf8');
  const rel = path.relative(ROOT, f);
  for (const m of src.matchAll(/@(string|drawable|color|layout|menu|mipmap|dimen|style|xml)\/([A-Za-z_][A-Za-z0-9_.]*)/g)) {
    const [, type, name] = m;
    if (type === 'style') {
      // Style names are dotted (e.g. Widget.DIY.Card) - resolve the full name.
      // Material/AppCompat parent styles are not local resources.
      const external = /^Widget\.MaterialComponents\./.test(name) ||
        /^TextAppearance\.MaterialComponents\./.test(name) ||
        /^Theme\.MaterialComponents\./.test(name) ||
        /^Theme\.AppCompat\./.test(name) ||
        /^Widget\.AppCompat\./.test(name);
      if (!defined.style.has(name) && !external) {
        problems.push(`${rel}: @style/${name}  (no such style)`);
      }
      continue;
    }
    const base = name.split('.')[0];
    if (!defined[type] || !defined[type].has(base)) {
      problems.push(`${rel}: @${type}/${name}  (no such ${type})`);
    }
  }
}

// ---- layout id audit: every id referenced from Kotlin must exist in a layout ----
const layoutIds = new Set();
for (const f of walk(RES)) {
  if (!f.includes('/layout') || !f.endsWith('.xml')) continue;
  const src = fs.readFileSync(f, 'utf8');
  for (const m of src.matchAll(/android:id="@\+id\/([A-Za-z_][A-Za-z0-9_]*)"/g)) layoutIds.add(m[1]);
}
for (const f of walk(SRC)) {
  if (!f.endsWith('.kt')) continue;
  const src = fs.readFileSync(f, 'utf8');
  const rel = path.relative(ROOT, f);
  for (const m of src.matchAll(/findViewById(?:<[^>]+>)?\(\s*R\.id\.([A-Za-z_][A-Za-z0-9_]*)/g)) {
    if (!layoutIds.has(m[1])) problems.push(`${rel}: R.id.${m[1]}  (not declared in any layout)`);
  }
}

// ---- duplicate string names across values files ----
const stringSources = new Map();
for (const f of walk(RES)) {
  if (!f.includes('/values') || !f.endsWith('.xml')) continue;
  const xml = fs.readFileSync(f, 'utf8');
  for (const m of xml.matchAll(/<string\s+name="([^"]+)"/g)) {
    const name = m[1];
    if (!stringSources.has(name)) stringSources.set(name, []);
    stringSources.get(name).push(path.basename(f));
  }
}
for (const [name, files] of stringSources) {
  if (files.length > 1) problems.push(`duplicate string "${name}" in ${files.join(', ')}`);
}

console.log('--- defined counts ---');
for (const k of Object.keys(defined)) console.log(`${k}: ${defined[k].size}`);
console.log(`layout ids: ${layoutIds.size}`);
console.log('\n--- problems ---');
if (problems.length === 0) console.log('none');
else problems.forEach(p => console.log(p));
console.log(`\ntotal problems: ${problems.length}`);
