# Keep calculator metadata (reflection is not used, but titles are looked up by id).
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
