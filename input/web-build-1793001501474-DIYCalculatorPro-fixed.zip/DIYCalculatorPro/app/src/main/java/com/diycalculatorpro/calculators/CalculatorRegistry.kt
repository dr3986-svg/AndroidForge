package com.diycalculatorpro.calculators

import com.diycalculatorpro.R
import com.diycalculatorpro.calculators.building.BrickCalculator
import com.diycalculatorpro.calculators.building.ConcreteCalculator
import com.diycalculatorpro.calculators.building.InsulationCalculator
import com.diycalculatorpro.calculators.building.MortarCalculator
import com.diycalculatorpro.calculators.building.StairsCalculator
import com.diycalculatorpro.calculators.building.TakeoffCalculator
import com.diycalculatorpro.calculators.electrical.CableSizeCalculator
import com.diycalculatorpro.calculators.electrical.DividerCalculator
import com.diycalculatorpro.calculators.electrical.OhmLawCalculator
import com.diycalculatorpro.calculators.electrical.PowerCalculator
import com.diycalculatorpro.calculators.electrical.VoltageDropCalculator
import com.diycalculatorpro.calculators.electrical.WireGaugeCalculator
import com.diycalculatorpro.calculators.painting.PaintQuantityCalculator
import com.diycalculatorpro.calculators.painting.RoomWallsCalculator
import com.diycalculatorpro.calculators.tiling.TileLayoutCalculator
import com.diycalculatorpro.calculators.tiling.TileQuantityCalculator
import com.diycalculatorpro.engine.CalculatorSpec
import com.diycalculatorpro.engine.Trade

/**
 * The single place where every calculator is registered.
 *
 * Adding a calculator means writing the engine, adding its strings and adding
 * one entry here — the lists, favourites and history pick it up automatically.
 */
object CalculatorRegistry {

    private val all: List<CalculatorSpec> = listOf(
        // ---- Electrical ----
        CalculatorSpec(
            id = "electrical_ohm",
            titleRes = R.string.calc_electrical_ohm_title,
            summaryRes = R.string.calc_electrical_ohm_summary,
            trade = Trade.ELECTRICAL,
            iconRes = R.drawable.ic_calc_ohm,
            fields = OhmLawCalculator.fields,
            calculator = OhmLawCalculator
        ),
        CalculatorSpec(
            id = "electrical_power",
            titleRes = R.string.calc_electrical_power_title,
            summaryRes = R.string.calc_electrical_power_summary,
            trade = Trade.ELECTRICAL,
            iconRes = R.drawable.ic_calc_power,
            fields = PowerCalculator.fields,
            calculator = PowerCalculator
        ),
        CalculatorSpec(
            id = "electrical_cable",
            titleRes = R.string.calc_electrical_cable_title,
            summaryRes = R.string.calc_electrical_cable_summary,
            trade = Trade.ELECTRICAL,
            iconRes = R.drawable.ic_calc_cable,
            fields = CableSizeCalculator.fields,
            calculator = CableSizeCalculator
        ),
        CalculatorSpec(
            id = "electrical_voltage_drop",
            titleRes = R.string.calc_electrical_vd_title,
            summaryRes = R.string.calc_electrical_vd_summary,
            trade = Trade.ELECTRICAL,
            iconRes = R.drawable.ic_calc_volt_drop,
            fields = VoltageDropCalculator.fields,
            calculator = VoltageDropCalculator
        ),
        CalculatorSpec(
            id = "electrical_divider",
            titleRes = R.string.calc_electrical_divider_title,
            summaryRes = R.string.calc_electrical_divider_summary,
            trade = Trade.ELECTRICAL,
            iconRes = R.drawable.ic_calc_divider,
            fields = DividerCalculator.fields,
            calculator = DividerCalculator
        ),
        CalculatorSpec(
            id = "electrical_gauge",
            titleRes = R.string.calc_electrical_gauge_title,
            summaryRes = R.string.calc_electrical_gauge_summary,
            trade = Trade.ELECTRICAL,
            iconRes = R.drawable.ic_calc_gauge,
            fields = WireGaugeCalculator.fields,
            calculator = WireGaugeCalculator
        ),

        // ---- Building ----
        CalculatorSpec(
            id = "building_concrete",
            titleRes = R.string.calc_building_concrete_title,
            summaryRes = R.string.calc_building_concrete_summary,
            trade = Trade.BUILDING,
            iconRes = R.drawable.ic_calc_concrete,
            fields = ConcreteCalculator.fields,
            calculator = ConcreteCalculator
        ),
        CalculatorSpec(
            id = "building_brick",
            titleRes = R.string.calc_building_brick_title,
            summaryRes = R.string.calc_building_brick_summary,
            trade = Trade.BUILDING,
            iconRes = R.drawable.ic_calc_brick,
            fields = BrickCalculator.fields,
            calculator = BrickCalculator
        ),
        CalculatorSpec(
            id = "building_stairs",
            titleRes = R.string.calc_building_stairs_title,
            summaryRes = R.string.calc_building_stairs_summary,
            trade = Trade.BUILDING,
            iconRes = R.drawable.ic_calc_stairs,
            fields = StairsCalculator.fields,
            calculator = StairsCalculator
        ),
        CalculatorSpec(
            id = "building_mortar",
            titleRes = R.string.calc_building_mortar_title,
            summaryRes = R.string.calc_building_mortar_summary,
            trade = Trade.BUILDING,
            iconRes = R.drawable.ic_calc_mortar,
            fields = MortarCalculator.fields,
            calculator = MortarCalculator
        ),
        CalculatorSpec(
            id = "building_insulation",
            titleRes = R.string.calc_building_insulation_title,
            summaryRes = R.string.calc_building_insulation_summary,
            trade = Trade.BUILDING,
            iconRes = R.drawable.ic_calc_insulation,
            fields = InsulationCalculator.fields,
            calculator = InsulationCalculator
        ),
        CalculatorSpec(
            id = "building_takeoff",
            titleRes = R.string.calc_building_takeoff_title,
            summaryRes = R.string.calc_building_takeoff_summary,
            trade = Trade.BUILDING,
            iconRes = R.drawable.ic_calc_takeoff,
            fields = TakeoffCalculator.fields,
            calculator = TakeoffCalculator
        ),

        // ---- Tiling ----
        CalculatorSpec(
            id = "tiling_quantity",
            titleRes = R.string.calc_tiling_quantity_title,
            summaryRes = R.string.calc_tiling_quantity_summary,
            trade = Trade.TILING,
            iconRes = R.drawable.ic_calc_tile,
            fields = TileQuantityCalculator.fields,
            calculator = TileQuantityCalculator
        ),
        CalculatorSpec(
            id = "tiling_layout",
            titleRes = R.string.calc_tiling_layout_title,
            summaryRes = R.string.calc_tiling_layout_summary,
            trade = Trade.TILING,
            iconRes = R.drawable.ic_calc_layout,
            fields = TileLayoutCalculator.fields,
            calculator = TileLayoutCalculator
        ),

        // ---- Painting ----
        CalculatorSpec(
            id = "painting_quantity",
            titleRes = R.string.calc_painting_quantity_title,
            summaryRes = R.string.calc_painting_quantity_summary,
            trade = Trade.PAINTING,
            iconRes = R.drawable.ic_calc_paint,
            fields = PaintQuantityCalculator.fields,
            calculator = PaintQuantityCalculator
        ),
        CalculatorSpec(
            id = "painting_walls",
            titleRes = R.string.calc_painting_walls_title,
            summaryRes = R.string.calc_painting_walls_summary,
            trade = Trade.PAINTING,
            iconRes = R.drawable.ic_calc_walls,
            fields = RoomWallsCalculator.fields,
            calculator = RoomWallsCalculator
        )
    )

    /** Every calculator, in display order. */
    val allCalculators: List<CalculatorSpec> = all

    /** Calculators grouped by trade, in trade order. */
    val byTrade: Map<Trade, List<CalculatorSpec>> =
        Trade.values().associateWith { trade -> all.filter { it.trade == trade } }

    private val byId: Map<String, CalculatorSpec> = all.associateBy { it.id }

    fun find(id: String): CalculatorSpec? = byId[id]

    fun require(id: String): CalculatorSpec =
        byId[id] ?: throw IllegalArgumentException("Unknown calculator: $id")

    /**
     * Case-insensitive search over the title, summary and trade name.
     *
     * The searchable text is cached by [primeSearchCache] so this does not
     * need a Resources instance.
     */
    fun search(query: String): List<CalculatorSpec> {
        val q = query.trim()
        if (q.isEmpty()) return all
        return all.filter { spec ->
            val title = TITLE_CACHE[spec.id].orEmpty()
            val summary = SUMMARY_CACHE[spec.id].orEmpty()
            title.contains(q, ignoreCase = true) ||
                summary.contains(q, ignoreCase = true) ||
                spec.trade.name.contains(q, ignoreCase = true)
        }
    }

    /**
     * Title and summary strings are cached here so [search] can match without
     * needing a Resources instance. The registry populates this at startup.
     */
    private val TITLE_CACHE = mutableMapOf<String, String>()
    private val SUMMARY_CACHE = mutableMapOf<String, String>()

    /** Fills the search cache. Call once the application context is available. */
    fun primeSearchCache(res: android.content.res.Resources) {
        all.forEach { spec ->
            TITLE_CACHE[spec.id] = res.getString(spec.titleRes)
            SUMMARY_CACHE[spec.id] = res.getString(spec.summaryRes)
        }
    }
}
