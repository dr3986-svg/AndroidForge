package com.diycalculatorpro.calculators.electrical

import com.diycalculatorpro.R
import com.diycalculatorpro.engine.CalcResult
import com.diycalculatorpro.engine.CalculatorEngine
import com.diycalculatorpro.engine.EngineContext
import com.diycalculatorpro.engine.NumberField
import com.diycalculatorpro.engine.ResultRow
import com.diycalculatorpro.engine.Units
import com.diycalculatorpro.engine.Validate
import com.diycalculatorpro.engine.Values


/**
 * Wire gauge and ampacity helper.
 *
 * Converts between AWG and mm² using the standard table and checks a run
 * against a 3% voltage-drop recommendation.
 */
object WireGaugeCalculator : CalculatorEngine {

    const val F_CURRENT = "current"
    const val F_LENGTH = "length"
    const val F_VOLTAGE = "voltage"

    /**
     * Typical single-conductor ampacity in open air, amps.
     *
     * The key is the AWG number; 1/0 AWG and larger are encoded as negative
     * values so they do not clash with the plain AWG numbers.
     */
    private val awgToAmps = listOf(
        14 to 15.0, 12 to 20.0, 10 to 30.0, 8 to 40.0, 6 to 55.0,
        4 to 70.0, 2 to 95.0, 1 to 110.0,
        -1 to 125.0, -2 to 150.0, -3 to 175.0, -4 to 200.0
    )

    /** Standard metric sizes offered in the results. */
    private val metricSizes = listOf(1.5, 2.5, 4.0, 6.0, 10.0, 16.0, 25.0, 32.0, 50.0, 70.0)

    /** Resistivity of copper at 20 °C, Ω·mm²/m. */
    private const val RHO_COPPER = 0.01724
    private const val ALPHA_COPPER = 0.00393
    private const val RUNNING_TEMP_C = 70.0

    val fields = listOf(
        NumberField(
            id = F_CURRENT,
            labelRes = R.string.f_electrical_gauge_current,
            unitOptions = listOf(Units.AMP),
            defaultUnitId = Units.AMP.id,
            allowZero = false
        ),
        NumberField(
            id = F_LENGTH,
            labelRes = R.string.f_electrical_gauge_length,
            unitOptions = listOf(Units.M, Units.MM, Units.CM, Units.FOOT),
            defaultUnitId = Units.M.id,
            allowZero = false
        ),
        NumberField(
            id = F_VOLTAGE,
            labelRes = R.string.f_electrical_gauge_voltage,
            unitOptions = listOf(Units.VOLT),
            defaultUnitId = Units.VOLT.id,
            allowZero = false
        )
    )

    private val currentField = fields.filterIsInstance<NumberField>().first { it.id == F_CURRENT }
    private val lengthField = fields.filterIsInstance<NumberField>().first { it.id == F_LENGTH }
    private val voltageField = fields.filterIsInstance<NumberField>().first { it.id == F_VOLTAGE }

    override fun calculate(values: Values, ctx: EngineContext): CalcResult {
        Validate.requireFields(values, listOf(currentField, lengthField, voltageField))
            ?.let { return it }

        val current = values.baseValue(currentField) ?: 0.0
        val length = values.baseValue(lengthField) ?: 0.0
        val voltage = values.baseValue(voltageField) ?: 0.0
        if (current <= 0.0) return CalcResult.error(F_CURRENT, Validate.ERR_POSITIVE)
        if (length <= 0.0) return CalcResult.error(F_LENGTH, Validate.ERR_POSITIVE)
        if (voltage <= 0.0) return CalcResult.error(F_VOLTAGE, Validate.ERR_POSITIVE)

        // Smallest standard size whose resistance keeps the drop within 3%.
        val maxResistance = (voltage * 0.03) / (current * 2.0)
        val requiredMm2 = RHO_COPPER * length / maxResistance
        val selected = metricSizes.firstOrNull { it >= requiredMm2 } ?: metricSizes.last()

        // Ampacity check against the AWG table.
        val ampacityEntry = awgToAmps.minByOrNull { absDiff(it.second, selected) }
        val ampacity = ampacityEntry?.second ?: 0.0
        val awgLabel = ampacityEntry?.let { awgName(it.first) } ?: "—"

        // Actual voltage drop for the selected size.
        val rHot = (RHO_COPPER * length / selected) * (1.0 + ALPHA_COPPER * (RUNNING_TEMP_C - 20.0))
        val drop = current * rHot * 2.0
        val percent = drop / voltage * 100.0

        val rows = mutableListOf(
            ResultRow(ctx.str(R.string.f_electrical_gauge_size), "${ctx.trim(selected, 1)} mm²", emphasise = true),
            ResultRow(ctx.str(R.string.f_electrical_gauge_awg), awgLabel, emphasise = true),
            ResultRow(ctx.str(R.string.f_electrical_gauge_ampacity), ctx.withUnit(ampacity, Units.AMP)),
            ResultRow(ctx.str(R.string.f_electrical_vd_drop), ctx.withUnit(drop, Units.VOLT)),
            ResultRow(ctx.str(R.string.f_electrical_vd_percent), "${ctx.trim(percent, 2)}%")
        )

        val notes = mutableListOf<String>()
        if (ampacity < current) {
            notes += ctx.str(R.string.f_electrical_gauge_note_over)
        }
        notes += ctx.str(R.string.f_electrical_gauge_note_table)
        notes += ctx.str(R.string.note_check_local)

        return CalcResult(
            headline = "${ctx.trim(selected, 1)} mm²",
            headlineLabel = ctx.str(R.string.f_electrical_gauge_size),
            rows = rows,
            notes = notes
        )
    }

    private fun absDiff(a: Double, b: Double): Double = if (a > b) a - b else b - a

    private fun awgName(awg: Int): String = when (awg) {
        -1 -> "1/0 AWG"
        -2 -> "2/0 AWG"
        -3 -> "3/0 AWG"
        -4 -> "4/0 AWG"
        else -> "$awg AWG"
    }
}
