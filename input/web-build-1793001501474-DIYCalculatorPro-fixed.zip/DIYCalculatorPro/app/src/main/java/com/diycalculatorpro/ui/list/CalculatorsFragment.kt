package com.diycalculatorpro.ui.list

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.diycalculatorpro.R
import com.diycalculatorpro.calculators.CalculatorRegistry
import com.diycalculatorpro.engine.CalculatorSpec
import com.diycalculatorpro.ui.MainActivity
import com.diycalculatorpro.ui.Services
import com.diycalculatorpro.ui.calculator.CalculatorActivity

/**
 * The full list of calculators, grouped by trade, with a search box.
 */
class CalculatorsFragment : Fragment() {

    private lateinit var adapter: CalculatorAdapter
    private lateinit var searchBox: EditText

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_calculators, container, false)

        searchBox = view.findViewById(R.id.search_input)
        val list = view.findViewById<RecyclerView>(R.id.calculator_list)

        adapter = CalculatorAdapter(
            onClick = { spec -> openCalculator(spec) },
            onFavouriteToggle = { spec, isFavourite -> toggleFavourite(spec, isFavourite) }
        )
        list.layoutManager = LinearLayoutManager(requireContext())
        list.adapter = adapter

        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                applyFilter(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })

        return view
    }

    override fun onResume() {
        super.onResume()
        adapter.setFavourites(Services.favourites(requireContext()).all().toSet())
        applyFilter(searchBox.text?.toString().orEmpty())
    }

    private fun applyFilter(query: String) {
        val results = CalculatorRegistry.search(query)
        if (query.isBlank()) {
            // Grouped by trade, preserving the trade order from the registry.
            val sections = CalculatorRegistry.byTrade.map { (trade, specs) ->
                trade.titleRes to specs
            }
            adapter.submitSections(sections)
        } else {
            adapter.submit(results)
        }
    }

    private fun toggleFavourite(spec: CalculatorSpec, currentlyFavourite: Boolean) {
        val store = Services.favourites(requireContext())
        store.toggle(spec.id)
        adapter.setFavourites(store.all().toSet())
        (activity as? MainActivity)?.toast(
            getString(
                if (currentlyFavourite) R.string.removed_from_favourites
                else R.string.added_to_favourites
            )
        )
    }

    private fun openCalculator(spec: CalculatorSpec) {
        startActivity(CalculatorActivity.intent(requireContext(), spec.id))
    }
}
