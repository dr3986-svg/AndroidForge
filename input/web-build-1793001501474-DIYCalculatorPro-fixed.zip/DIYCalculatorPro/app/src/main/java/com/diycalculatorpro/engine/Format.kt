package com.diycalculatorpro.engine

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.math.abs

/**
 * Number formatting shared by every calculator.
 *
 * All formatting uses a fixed decimal separator (`.`) so results are
 * unambiguous on site; the unit label carries the meaning instead.
 */
object Format {

    /** Rounds [value] to [decimals] places, half-up. */
    fun round(value: Double, decimals: Int): Double {
        if (!value.isFinite()) return value
        val factor = Math.pow(10.0, decimals.toDouble())
        return kotlin.math.round(value * factor) / factor
    }

    /** Formats [value] with exactly [decimals] decimal places. */
    fun decimal(value: Double, decimals: Int): String {
        if (!value.isFinite()) return "—"
        val df = DecimalFormat("0." + "#".repeat(decimals.coerceIn(0, 6)), DecimalFormatSymbols(Locale.US))
        df.roundingMode = java.math.RoundingMode.HALF_UP
        return df.format(round(value, decimals))
    }

    /** Formats [value] dropping trailing zeros (up to [decimals] places). */
    fun trim(value: Double, decimals: Int = 2): String {
        if (!value.isFinite()) return "—"
        val rounded = round(value, decimals)
        if (rounded == kotlin.math.floor(rounded) && abs(rounded) < 1e15) {
            return rounded.toLong().toString()
        }
        return decimal(rounded, decimals)
    }

    /** Formats a number with its unit label, e.g. `12.5 m²`. */
    fun withUnit(value: Double, unitLabel: String, decimals: Int = 2): String =
        if (unitLabel.isEmpty()) trim(value, decimals) else "${trim(value, decimals)} $unitLabel"

    /** Percentage with a trailing sign, e.g. `+12.5%`. */
    fun signedPercent(value: Double, decimals: Int = 1): String {
        val sign = if (value > 0) "+" else ""
        return "$sign${decimal(value, decimals)}%"
    }

    /**
     * Chooses a sensible decimal count so small values stay readable and
     * large values stay compact.
     */
    fun autoDecimals(value: Double): Int = when {
        !value.isFinite() -> 2
        abs(value) >= 1000 -> 1
        abs(value) >= 1 -> 2
        abs(value) >= 0.01 -> 3
        abs(value) == 0.0 -> 0
        else -> 4
    }
}
