package com.diycalculatorpro.engine

/**
 * Validation helpers shared by all calculators.
 *
 * Every calculator validates through these so the error wording and the
 * field highlighting behave identically across the app.
 */
object Validate {

    /**
     * Validates a numeric field.
     *
     * @return null when the value is acceptable, otherwise an error message.
     */
    fun number(values: Values, field: NumberField): String? {
        val raw = values.numbers[field.id]
        if (raw == null) {
            return if (field.required) ERR_REQUIRED else null
        }
        if (raw.isNaN() || raw.isInfinite()) return ERR_NUMBER
        if (!field.allowZero && raw == 0.0) return ERR_NOT_ZERO
        if (raw < 0.0 && (field.min == null || field.min >= 0.0)) return ERR_NEGATIVE
        field.min?.let { if (raw < it) return ERR_BELOW_MIN }
        field.max?.let { if (raw > it) return ERR_ABOVE_MAX }
        return null
    }

    /**
     * Validates a choice field and returns the selected option id.
     */
    fun choice(values: Values, field: ChoiceField): String? {
        val selected = values.choices[field.id] ?: field.defaultOptionId
        return if (field.options.any { it.id == selected }) selected else null
    }

    /** Collects the first validation problem as a [CalcResult]. */
    fun firstError(values: Values, fields: List<Field>): CalcResult? {
        for (field in fields) {
            when (field) {
                is NumberField -> {
                    val message = number(values, field)
                    if (message != null) {
                        return CalcResult.error(field.id, message)
                    }
                }
                is ChoiceField -> {
                    if (choice(values, field) == null) {
                        return CalcResult.error(field.id, ERR_CHOOSE)
                    }
                }
            }
        }
        return null
    }

    /** Validates that the given fields are present and usable. */
    fun requireFields(values: Values, fields: List<NumberField>): CalcResult? {
        for (field in fields) {
            val message = number(values, field)
            if (message != null) return CalcResult.error(field.id, message)
        }
        return null
    }

    /**
     * Requires [field] to have been filled in, even though the field itself is
     * declared optional. Used when a field is only needed for some of the
     * choices offered by the form.
     */
    fun requirePresent(values: Values, field: NumberField): CalcResult? {
        if (!values.numbers.containsKey(field.id)) {
            return CalcResult.error(field.id, ERR_REQUIRED)
        }
        val message = number(values, field)
        if (message != null) return CalcResult.error(field.id, message)
        return null
    }

    const val ERR_REQUIRED = "This value is required"
    const val ERR_POSITIVE = "Must be greater than zero"
    const val ERR_NOT_ZERO = "Must not be zero"
    const val ERR_NEGATIVE = "Cannot be negative"
    const val ERR_ABOVE_MAX = "Value is too large"
    const val ERR_BELOW_MIN = "Value is too small"
    const val ERR_NUMBER = "Enter a valid number"
    const val ERR_CHOOSE = "Choose an option"
    const val ERR_DIVIDE_BY_ZERO = "Cannot divide by zero"
    const val ERR_MATH = "Those values do not produce a sensible result"
}
