package com.diycalculatorpro.calculators.building

import com.diycalculatorpro.R
import com.diycalculatorpro.engine.CalcResult
import com.diycalculatorpro.engine.CalculatorEngine
import com.diycalculatorpro.engine.ChoiceField
import com.diycalculatorpro.engine.ChoiceOption
import com.diycalculatorpro.engine.EngineContext
import com.diycalculatorpro.engine.NumberField
import com.diycalculatorpro.engine.ResultRow
import com.diycalculatorpro.engine.Units
import com.diycalculatorpro.engine.Validate
import com.diycalculatorpro.engine.Values
import kotlin.math.ceil

/**
 * Insulation and drylining quantities.
 *
 * Coverage per product is fixed: a mineral wool roll covers 10 m², a
 * 1200 × 600 mm batt covers 0.72 m² and a 1.2 × 2.4 m board covers 2.88 m².
 */
object InsulationCalculator : CalculatorEngine {

    const val F_AREA = "area"
    const val F_THICKNESS = "thickness"
    const val F_PRODUCT = "product"
    const val F_WASTE = "waste"

    const val PRODUCT_ROLL = "roll"
    const val PRODUCT_BATT = "batt"
    const val PRODUCT_BOARD = "board"

    private val coverage = mapOf(
        PRODUCT_ROLL to 10.0,
        PRODUCT_BATT to 0.72,
        PRODUCT_BOARD to 2.88
    )

    val fields = listOf(
        NumberField(
            id = F_AREA,
            labelRes = R.string.f_building_insulation_area,
            unitOptions = listOf(Units.M2, Units.FT2),
            defaultUnitId = Units.M2.id,
            allowZero = false
        ),
        NumberField(
            id = F_THICKNESS,
            labelRes = R.string.f_building_insulation_thickness,
            unitOptions = listOf(Units.MM, Units.CM, Units.INCH),
            defaultUnitId = Units.MM.id,
            allowZero = false
        ),
        ChoiceField(
            id = F_PRODUCT,
            labelRes = R.string.f_building_insulation_product,
            options = listOf(
                ChoiceOption(PRODUCT_ROLL, R.string.opt_product_roll),
                ChoiceOption(PRODUCT_BATT, R.string.opt_product_batt),
                ChoiceOption(PRODUCT_BOARD, R.string.opt_product_board)
            ),
            defaultOptionId = PRODUCT_ROLL
        ),
        NumberField(
            id = F_WASTE,
            labelRes = R.string.f_building_insulation_waste,
            min = 0.0,
            max = 50.0,
            helperRes = R.string.f_building_insulation_waste_helper
        )
    )

    private val areaField = fields.filterIsInstance<NumberField>().first { it.id == F_AREA }
    private val thicknessField = fields.filterIsInstance<NumberField>().first { it.id == F_THICKNESS }
    private val wasteField = fields.filterIsInstance<NumberField>().first { it.id == F_WASTE }

    override fun calculate(values: Values, ctx: EngineContext): CalcResult {
        Validate.requireFields(values, listOf(areaField))?.let { return it }

        val area = values.baseValue(areaField) ?: 0.0
        if (area <= 0.0) return CalcResult.error(F_AREA, Validate.ERR_POSITIVE)

        val thickness = values.baseValue(thicknessField) ?: 0.0
        val wastePercent = values.numbers[wasteField.id] ?: 10.0
        val product = values.choices[F_PRODUCT] ?: PRODUCT_ROLL
        val perUnit = coverage[product] ?: 10.0

        val areaWithWaste = area * (1.0 + wastePercent / 100.0)
        val units = ceil(areaWithWaste / perUnit)
        val volume = area * thickness

        val unitName = when (product) {
            PRODUCT_ROLL -> ctx.str(R.string.f_building_insulation_rolls)
            PRODUCT_BATT -> ctx.str(R.string.f_building_insulation_batts)
            else -> ctx.str(R.string.f_building_insulation_boards)
        }

        val rows = mutableListOf(
            ResultRow(
                ctx.str(R.string.f_building_insulation_area_with_waste),
                ctx.withUnit(areaWithWaste, Units.M2),
                emphasise = true
            ),
            ResultRow(unitName, "${ctx.trim(units, 0)}", emphasise = true),
            ResultRow(ctx.str(R.string.f_building_insulation_volume), ctx.withUnit(volume, Units.M3, 3)),
            ResultRow(ctx.str(R.string.f_building_insulation_coverage), "${ctx.trim(perUnit, 2)} m² each")
        )

        val notes = mutableListOf<String>()
        notes += ctx.str(R.string.note_order_extra)
        notes += ctx.str(R.string.note_check_manufacturer)

        return CalcResult(
            headline = "${ctx.trim(units, 0)}",
            headlineLabel = unitName,
            rows = rows,
            notes = notes
        )
    }
}
