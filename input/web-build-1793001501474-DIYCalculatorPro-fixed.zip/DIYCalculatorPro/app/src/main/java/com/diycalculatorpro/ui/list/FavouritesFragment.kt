package com.diycalculatorpro.ui.list

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.diycalculatorpro.R
import com.diycalculatorpro.calculators.CalculatorRegistry
import com.diycalculatorpro.engine.CalculatorSpec
import com.diycalculatorpro.ui.MainActivity
import com.diycalculatorpro.ui.Services
import com.diycalculatorpro.ui.calculator.CalculatorActivity

/**
 * The user's pinned calculators.
 */
class FavouritesFragment : Fragment() {

    private lateinit var adapter: CalculatorAdapter
    private lateinit var emptyView: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_favourites, container, false)

        emptyView = view.findViewById(R.id.empty_message)
        val list = view.findViewById<RecyclerView>(R.id.favourite_list)

        adapter = CalculatorAdapter(
            onClick = { spec -> openCalculator(spec) },
            onFavouriteToggle = { spec, isFavourite -> toggleFavourite(spec, isFavourite) }
        )
        list.layoutManager = LinearLayoutManager(requireContext())
        list.adapter = adapter

        return view
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val ids = Services.favourites(requireContext()).all()
        val specs = ids.mapNotNull { CalculatorRegistry.find(it) }
        adapter.submit(specs)
        adapter.setFavourites(ids.toSet())
        emptyView.visibility = if (specs.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun toggleFavourite(spec: CalculatorSpec, currentlyFavourite: Boolean) {
        val store = Services.favourites(requireContext())
        store.toggle(spec.id)
        refresh()
        (activity as? MainActivity)?.toast(
            getString(
                if (currentlyFavourite) R.string.removed_from_favourites
                else R.string.added_to_favourites
            )
        )
    }

    private fun openCalculator(spec: CalculatorSpec) {
        startActivity(CalculatorActivity.intent(requireContext(), spec.id))
    }
}
