package com.diycalculatorpro.ui.list

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.diycalculatorpro.R
import com.diycalculatorpro.engine.CalculatorSpec

/**
 * One row in the calculator list: either a section header or a calculator.
 */
sealed class CalculatorListItem {
    data class Header(val titleRes: Int) : CalculatorListItem()
    data class Entry(val spec: CalculatorSpec) : CalculatorListItem()
}

/**
 * Adapter for the calculator list and the favourites list.
 *
 * Supports optional section headers so the main list can group calculators
 * by trade without nesting RecyclerViews.
 */
class CalculatorAdapter(
    private val onClick: (CalculatorSpec) -> Unit,
    private val onFavouriteToggle: ((CalculatorSpec, Boolean) -> Unit)? = null
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val items = mutableListOf<CalculatorListItem>()
    private var favouriteIds: Set<String> = emptySet()

    /** Replaces the list contents with a flat list of calculators. */
    fun submit(specs: List<CalculatorSpec>) {
        items.clear()
        specs.forEach { items.add(CalculatorListItem.Entry(it)) }
        notifyDataSetChanged()
    }

    /** Replaces the list contents with headers and calculators. */
    fun submitSections(sections: List<Pair<Int, List<CalculatorSpec>>>) {
        items.clear()
        sections.forEach { (titleRes, specs) ->
            if (specs.isEmpty()) return@forEach
            items.add(CalculatorListItem.Header(titleRes))
            specs.forEach { items.add(CalculatorListItem.Entry(it)) }
        }
        notifyDataSetChanged()
    }

    /** Updates which items show as favourites without rebuilding the list. */
    fun setFavourites(ids: Set<String>) {
        favouriteIds = ids
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int = when (items[position]) {
        is CalculatorListItem.Header -> TYPE_HEADER
        is CalculatorListItem.Entry -> TYPE_ENTRY
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_HEADER) {
            HeaderHolder(inflater.inflate(R.layout.item_section_header, parent, false))
        } else {
            EntryHolder(inflater.inflate(R.layout.item_calculator, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = items[position]) {
            is CalculatorListItem.Header -> (holder as HeaderHolder).bind(item.titleRes)
            is CalculatorListItem.Entry -> (holder as EntryHolder).bind(item.spec)
        }
    }

    override fun getItemCount(): Int = items.size

    inner class HeaderHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val title: TextView = itemView.findViewById(R.id.section_title)

        fun bind(titleRes: Int) {
            title.setText(titleRes)
        }
    }

    inner class EntryHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val icon: ImageView = itemView.findViewById(R.id.icon)
        private val title: TextView = itemView.findViewById(R.id.title)
        private val summary: TextView = itemView.findViewById(R.id.summary)
        private val badge: TextView = itemView.findViewById(R.id.trade_badge)
        private val star: ImageView = itemView.findViewById(R.id.favourite)

        fun bind(spec: CalculatorSpec) {
            val context = itemView.context
            title.text = context.getString(spec.titleRes)
            summary.text = context.getString(spec.summaryRes)
            icon.setImageResource(spec.iconRes)
            icon.setColorFilter(ContextCompat.getColor(context, spec.trade.accentRes))
            badge.text = context.getString(spec.trade.titleRes)
            badge.setTextColor(ContextCompat.getColor(context, spec.trade.accentRes))

            val isFavourite = favouriteIds.contains(spec.id)
            star.setImageResource(
                if (isFavourite) R.drawable.ic_star_filled else R.drawable.ic_star_outline
            )
            star.alpha = if (isFavourite) 1f else 0.4f
            star.contentDescription = context.getString(R.string.action_favourite)
            star.setOnClickListener { onFavouriteToggle?.invoke(spec, isFavourite) }

            itemView.setOnClickListener { onClick(spec) }
        }
    }

    companion object {
        private const val TYPE_HEADER = 0
        private const val TYPE_ENTRY = 1
    }
}
