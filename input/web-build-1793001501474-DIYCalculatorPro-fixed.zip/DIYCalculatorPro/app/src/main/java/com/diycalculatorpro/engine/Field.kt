package com.diycalculatorpro.engine

import android.content.res.Resources

/**
 * A single input on a calculator form.
 *
 * [NumberField] values are stored in the unit the user picked; use
 * [Values.baseValue] to convert to the canonical unit before doing maths.
 */
sealed class Field {
    abstract val id: String
    abstract val labelRes: Int

    /** Unit options offered for this field (empty for pure choice fields). */
    open val unitOptions: List<UnitSpec> = emptyList()
}

data class NumberField(
    override val id: String,
    override val labelRes: Int,
    override val unitOptions: List<UnitSpec> = emptyList(),
    /** Unit selected when the form is first built. */
    val defaultUnitId: String? = null,
    val min: Double? = null,
    val max: Double? = null,
    /** When false a zero entry is rejected with a dedicated message. */
    val allowZero: Boolean = true,
    val required: Boolean = true,
    /** Extra hint under the input, e.g. a code reference. */
    val helperRes: Int? = null
) : Field() {
    /**
     * Units the user may pick for this field. Empty means the field is unitless.
     */
    val units: List<UnitSpec> get() = unitOptions
}

data class ChoiceOption(
    val id: String,
    val labelRes: Int,
    /** Overrides [labelRes] with a literal label, e.g. "2.5 mm²". */
    val labelOverride: String? = null
)

data class ChoiceField(
    override val id: String,
    override val labelRes: Int,
    val options: List<ChoiceOption>,
    val defaultOptionId: String = options.first().id
) : Field() {
    fun option(optionId: String): ChoiceOption? = options.firstOrNull { it.id == optionId }

    fun labelFor(res: Resources, optionId: String): String {
        val opt = option(optionId) ?: return optionId
        return opt.labelOverride ?: res.getString(opt.labelRes)
    }
}
