package com.diycalculatorpro.engine

/** One line in the result panel. */
data class ResultRow(
    val label: String,
    val value: String,
    /** Highlighted rows use the accent colour and a heavier weight. */
    val emphasise: Boolean = false
)

/**
 * Outcome of a calculation.
 *
 * A result is either a success (headline + rows + notes) or an error that
 * points at the offending input.
 */
data class CalcResult(
    val headline: String,
    val headlineLabel: String,
    val rows: List<ResultRow> = emptyList(),
    val notes: List<String> = emptyList(),
    val errorFieldId: String? = null,
    val errorMessage: String? = null
) {
    val isError: Boolean get() = errorMessage != null

    companion object {
        fun error(fieldId: String?, message: String): CalcResult =
            CalcResult("", "", emptyList(), emptyList(), fieldId, message)
    }
}
