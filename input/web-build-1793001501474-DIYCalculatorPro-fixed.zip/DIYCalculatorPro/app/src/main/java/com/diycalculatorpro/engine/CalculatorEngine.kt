package com.diycalculatorpro.engine

/**
 * The contract every calculator implements.
 *
 * Implementations receive validated input and must never throw for bad user
 * data — instead they return [CalcResult.error] with the id of the offending
 * field so the UI can highlight it.
 */
fun interface CalculatorEngine {
    /**
     * @param values the current form state
     * @param ctx    helpers for unit conversion and formatting
     */
    fun calculate(values: Values, ctx: EngineContext): CalcResult
}

/**
 * Shared helpers handed to every [CalculatorEngine].
 */
class EngineContext(
    val res: android.content.res.Resources,
    val unitSystem: UnitSystem,
    val decimals: Int = 2
) {
    /** Resolves a string resource. */
    fun str(id: Int): String = res.getString(id)

    /** Converts [field]'s value into [target]. */
    fun convert(values: Values, field: NumberField, target: UnitSpec): Double? =
        values.valueIn(field, target)

    /** The value of [field] in its own canonical base unit. */
    fun base(values: Values, field: NumberField): Double? = values.baseValue(field)

    /** Formats with the user's preferred decimal count. */
    fun num(value: Double, decimals: Int = this.decimals): String =
        Format.decimal(value, decimals)

    /** Formats with trailing zeros removed. */
    fun trim(value: Double, decimals: Int = this.decimals): String =
        Format.trim(value, decimals)

    /** Formats a value plus unit label. */
    fun withUnit(value: Double, unit: UnitSpec, decimals: Int = this.decimals): String =
        Format.withUnit(value, unit.label, decimals)
}
