package com.diycalculatorpro.engine

/**
 * Physical quantity families. Every [UnitSpec] belongs to exactly one dimension so that
 * unit pickers can offer only sensible choices for a given field.
 */
enum class Dimension {
    /** Sentinel dimension for unitless values (ratios, counts, percentages). */
    NONE,
    LENGTH,
    AREA,
    VOLUME,
    MASS,
    TIME,
    TEMPERATURE,
    VOLTAGE,
    CURRENT,
    RESISTANCE,
    POWER,
    ENERGY,
    FREQUENCY,
    ANGLE,
    FLOW,
    PRESSURE,
    SPEED
}

/** User preference ordering for unit pickers. */
enum class UnitSystem {
    METRIC,
    IMPERIAL
}

/**
 * A unit definition.
 *
 * The canonical (base) unit of a dimension is defined by [factor] / [offset]:
 * `base = value * factor + offset` and `fromBase(base) = (base - offset) / factor`.
 * This affine form covers both simple ratios (mm -> m) and offset scales (degF -> degC).
 */
data class UnitSpec(
    val id: String,
    val label: String,
    val dimension: Dimension,
    val factor: Double = 1.0,
    val offset: Double = 0.0,
    val decimals: Int = 2,
    /** Which unit system this unit belongs to; null means it is used by both. */
    val preference: UnitSystem? = null
) {
    fun toBase(value: Double): Double = value * factor + offset
    fun fromBase(base: Double): Double = (base - offset) / factor
}

/**
 * Registry of every unit used by the app.
 *
 * Base units: m, m2, m3, kg, s, degC, V, A, ohm, W, J, Hz, deg, m3/s, Pa, m/s.
 */
object Units {

    /**
     * Sentinel used for fields that carry no unit at all (ratios, counts,
     * percentages). Converting through it is the identity function.
     */
    val NONE = UnitSpec("none", "", Dimension.NONE, 1.0, 0.0, decimals = 2)

    // ---- length (base: metre) ----
    val MM = UnitSpec("mm", "mm", Dimension.LENGTH, 0.001, decimals = 1, preference = UnitSystem.METRIC)
    val CM = UnitSpec("cm", "cm", Dimension.LENGTH, 0.01, decimals = 1, preference = UnitSystem.METRIC)
    val M = UnitSpec("m", "m", Dimension.LENGTH, 1.0, decimals = 2)
    val KM = UnitSpec("km", "km", Dimension.LENGTH, 1000.0, decimals = 3, preference = UnitSystem.METRIC)
    val INCH = UnitSpec("in", "in", Dimension.LENGTH, 0.0254, decimals = 2, preference = UnitSystem.IMPERIAL)
    val FOOT = UnitSpec("ft", "ft", Dimension.LENGTH, 0.3048, decimals = 2, preference = UnitSystem.IMPERIAL)
    val YARD = UnitSpec("yd", "yd", Dimension.LENGTH, 0.9144, decimals = 2, preference = UnitSystem.IMPERIAL)
    val MILE = UnitSpec("mi", "mi", Dimension.LENGTH, 1609.344, decimals = 3, preference = UnitSystem.IMPERIAL)

    // ---- area (base: m2) ----
    val MM2 = UnitSpec("mm2", "mm²", Dimension.AREA, 1e-6, decimals = 1, preference = UnitSystem.METRIC)
    val CM2 = UnitSpec("cm2", "cm²", Dimension.AREA, 1e-4, decimals = 1, preference = UnitSystem.METRIC)
    val M2 = UnitSpec("m2", "m²", Dimension.AREA, 1.0, decimals = 2)
    val HA = UnitSpec("ha", "ha", Dimension.AREA, 10000.0, decimals = 3, preference = UnitSystem.METRIC)
    val IN2 = UnitSpec("in2", "in²", Dimension.AREA, 6.4516e-4, decimals = 1, preference = UnitSystem.IMPERIAL)
    val FT2 = UnitSpec("ft2", "ft²", Dimension.AREA, 0.09290304, decimals = 2, preference = UnitSystem.IMPERIAL)
    val YD2 = UnitSpec("yd2", "yd²", Dimension.AREA, 0.83612736, decimals = 2, preference = UnitSystem.IMPERIAL)
    val ACRE = UnitSpec("acre", "acre", Dimension.AREA, 4046.8564224, decimals = 3, preference = UnitSystem.IMPERIAL)

    // ---- volume (base: m3) ----
    val ML = UnitSpec("ml", "ml", Dimension.VOLUME, 1e-6, decimals = 1, preference = UnitSystem.METRIC)
    val L = UnitSpec("l", "L", Dimension.VOLUME, 0.001, decimals = 2, preference = UnitSystem.METRIC)
    val M3 = UnitSpec("m3", "m³", Dimension.VOLUME, 1.0, decimals = 3)
    val IN3 = UnitSpec("in3", "in³", Dimension.VOLUME, 1.6387064e-5, decimals = 1, preference = UnitSystem.IMPERIAL)
    val FT3 = UnitSpec("ft3", "ft³", Dimension.VOLUME, 0.028316846592, decimals = 2, preference = UnitSystem.IMPERIAL)
    val GAL_US = UnitSpec("gal_us", "gal (US)", Dimension.VOLUME, 0.003785411784, decimals = 2, preference = UnitSystem.IMPERIAL)
    val GAL_UK = UnitSpec("gal_uk", "gal (UK)", Dimension.VOLUME, 0.00454609, decimals = 2, preference = UnitSystem.IMPERIAL)

    // ---- mass (base: kg) ----
    val G = UnitSpec("g", "g", Dimension.MASS, 0.001, decimals = 0, preference = UnitSystem.METRIC)
    val KG = UnitSpec("kg", "kg", Dimension.MASS, 1.0, decimals = 2)
    val TONNE = UnitSpec("t", "t", Dimension.MASS, 1000.0, decimals = 3, preference = UnitSystem.METRIC)
    val OUNCE = UnitSpec("oz", "oz", Dimension.MASS, 0.028349523125, decimals = 2, preference = UnitSystem.IMPERIAL)
    val POUND = UnitSpec("lb", "lb", Dimension.MASS, 0.45359237, decimals = 2, preference = UnitSystem.IMPERIAL)

    // ---- time (base: second) ----
    val SEC = UnitSpec("s", "s", Dimension.TIME, 1.0, decimals = 1)
    val MIN = UnitSpec("min", "min", Dimension.TIME, 60.0, decimals = 1)
    val HOUR = UnitSpec("h", "h", Dimension.TIME, 3600.0, decimals = 1)
    val DAY = UnitSpec("day", "day", Dimension.TIME, 86400.0, decimals = 0)

    // ---- temperature (base: degC) ----
    val CELSIUS = UnitSpec("c", "°C", Dimension.TEMPERATURE, 1.0, 0.0, decimals = 1)
    val FAHRENHEIT = UnitSpec("f", "°F", Dimension.TEMPERATURE, 5.0 / 9.0, -32.0, decimals = 1, preference = UnitSystem.IMPERIAL)
    val KELVIN = UnitSpec("k", "K", Dimension.TEMPERATURE, 1.0, -273.15, decimals = 1)

    // ---- electrical (base: V, A, ohm, W, J, Hz) ----
    val VOLT = UnitSpec("v", "V", Dimension.VOLTAGE, 1.0, decimals = 1)
    val MILLIVOLT = UnitSpec("mv", "mV", Dimension.VOLTAGE, 0.001, decimals = 1, preference = UnitSystem.METRIC)
    val KILOVOLT = UnitSpec("kv", "kV", Dimension.VOLTAGE, 1000.0, decimals = 2, preference = UnitSystem.METRIC)
    val AMP = UnitSpec("a", "A", Dimension.CURRENT, 1.0, decimals = 2)
    val MILLIAMP = UnitSpec("ma", "mA", Dimension.CURRENT, 0.001, decimals = 1, preference = UnitSystem.METRIC)
    val KILOAMP = UnitSpec("ka", "kA", Dimension.CURRENT, 1000.0, decimals = 2, preference = UnitSystem.METRIC)
    val OHM = UnitSpec("ohm", "Ω", Dimension.RESISTANCE, 1.0, decimals = 2)
    val KILOOHM = UnitSpec("kohm", "kΩ", Dimension.RESISTANCE, 1000.0, decimals = 2, preference = UnitSystem.METRIC)
    val MEGOHM = UnitSpec("Mohm", "MΩ", Dimension.RESISTANCE, 1e6, decimals = 3, preference = UnitSystem.METRIC)
    val WATT = UnitSpec("w", "W", Dimension.POWER, 1.0, decimals = 1)
    val KILOWATT = UnitSpec("kw", "kW", Dimension.POWER, 1000.0, decimals = 2, preference = UnitSystem.METRIC)
    val HORSEPOWER = UnitSpec("hp", "hp", Dimension.POWER, 745.699872, decimals = 2, preference = UnitSystem.IMPERIAL)
    val JOULE = UnitSpec("j", "J", Dimension.ENERGY, 1.0, decimals = 0)
    val KILOJOULE = UnitSpec("kj", "kJ", Dimension.ENERGY, 1000.0, decimals = 1, preference = UnitSystem.METRIC)
    val WATT_HOUR = UnitSpec("wh", "Wh", Dimension.ENERGY, 3600.0, decimals = 0)
    val KILOWATT_HOUR = UnitSpec("kwh", "kWh", Dimension.ENERGY, 3.6e6, decimals = 2, preference = UnitSystem.METRIC)
    val HERTZ = UnitSpec("hz", "Hz", Dimension.FREQUENCY, 1.0, decimals = 0)
    val KILOHERTZ = UnitSpec("khz", "kHz", Dimension.FREQUENCY, 1000.0, decimals = 1, preference = UnitSystem.METRIC)

    // ---- misc ----
    val DEGREE = UnitSpec("deg", "°", Dimension.ANGLE, 1.0, decimals = 2)
    val RADIAN = UnitSpec("rad", "rad", Dimension.ANGLE, 57.29577951308232, decimals = 4, preference = UnitSystem.METRIC)
    val BAR = UnitSpec("bar", "bar", Dimension.PRESSURE, 1e5, decimals = 2, preference = UnitSystem.METRIC)
    val PSI = UnitSpec("psi", "psi", Dimension.PRESSURE, 6894.757293168, decimals = 2, preference = UnitSystem.IMPERIAL)
    val KPA = UnitSpec("kpa", "kPa", Dimension.PRESSURE, 1000.0, decimals = 1, preference = UnitSystem.METRIC)
    val LPM = UnitSpec("lpm", "L/min", Dimension.FLOW, 1.0 / 60000.0, decimals = 2, preference = UnitSystem.METRIC)
    val LPS = UnitSpec("lps", "L/s", Dimension.FLOW, 0.001, decimals = 3, preference = UnitSystem.METRIC)
    val CUM = UnitSpec("cum", "m³/s", Dimension.FLOW, 1.0, decimals = 4)
    val GPM_US = UnitSpec("gpm_us", "gal/min (US)", Dimension.FLOW, 6.30901964e-5, decimals = 2, preference = UnitSystem.IMPERIAL)
    val MPS = UnitSpec("mps", "m/s", Dimension.SPEED, 1.0, decimals = 2)
    val KMH = UnitSpec("kmh", "km/h", Dimension.SPEED, 1.0 / 3.6, decimals = 2, preference = UnitSystem.METRIC)
    val MPH = UnitSpec("mph", "mph", Dimension.SPEED, 0.44704, decimals = 2, preference = UnitSystem.IMPERIAL)

    val ALL: List<UnitSpec> = listOf(
        MM, CM, M, KM, INCH, FOOT, YARD, MILE,
        MM2, CM2, M2, HA, IN2, FT2, YD2, ACRE,
        ML, L, M3, IN3, FT3, GAL_US, GAL_UK,
        G, KG, TONNE, OUNCE, POUND,
        SEC, MIN, HOUR, DAY,
        CELSIUS, FAHRENHEIT, KELVIN,
        VOLT, MILLIVOLT, KILOVOLT,
        AMP, MILLIAMP, KILOAMP,
        OHM, KILOOHM, MEGOHM,
        WATT, KILOWATT, HORSEPOWER,
        JOULE, KILOJOULE, WATT_HOUR, KILOWATT_HOUR,
        HERTZ, KILOHERTZ,
        DEGREE, RADIAN, BAR, PSI, KPA,
        LPM, LPS, CUM, GPM_US,
        MPS, KMH, MPH
    )

    private val byId: Map<String, UnitSpec> by lazy { ALL.associateBy { it.id } }

    fun byId(id: String): UnitSpec? = byId[id]

    fun label(id: String): String = byId[id]?.label ?: id

    /**
     * Units of [dimension] ordered so the units the user prefers come first.
     */
    fun options(dimension: Dimension, system: UnitSystem): List<UnitSpec> =
        ALL.filter { it.dimension == dimension }.sortedBy { rank(it, system) }

    private fun rank(unit: UnitSpec, system: UnitSystem): Int = when (unit.preference) {
        system -> 0
        null -> 1
        else -> 2
    }
}
