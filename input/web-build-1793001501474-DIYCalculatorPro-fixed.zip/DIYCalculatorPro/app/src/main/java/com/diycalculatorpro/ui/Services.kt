package com.diycalculatorpro.ui

import android.content.Context
import com.diycalculatorpro.App
import com.diycalculatorpro.data.FavouritesStore
import com.diycalculatorpro.data.HistoryStore
import com.diycalculatorpro.data.Preferences

/**
 * Small helper for reaching the app singletons from a Context.
 */
object Services {

    private fun app(context: Context): App =
        context.applicationContext as App

    fun preferences(context: Context): Preferences = app(context).preferences

    fun favourites(context: Context): FavouritesStore = app(context).favourites

    fun history(context: Context): HistoryStore = app(context).history
}
