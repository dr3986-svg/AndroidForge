package com.diycalculatorpro.ui.list

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.diycalculatorpro.R
import com.diycalculatorpro.engine.UnitSystem
import com.diycalculatorpro.ui.Services

/**
 * App settings: unit preference, decimal places, screen-on and history.
 */
class SettingsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_settings, container, false)
        val preferences = Services.preferences(requireContext())

        // Unit system
        val unitGroup = view.findViewById<RadioGroup>(R.id.unit_group)
        val metric = view.findViewById<RadioButton>(R.id.unit_metric)
        val imperial = view.findViewById<RadioButton>(R.id.unit_imperial)
        if (preferences.unitSystem == UnitSystem.METRIC) metric.isChecked = true else imperial.isChecked = true
        unitGroup.setOnCheckedChangeListener { _, checkedId ->
            preferences.unitSystem = if (checkedId == R.id.unit_metric) {
                UnitSystem.METRIC
            } else {
                UnitSystem.IMPERIAL
            }
        }

        // Decimal places
        val decimalsGroup = view.findViewById<RadioGroup>(R.id.decimals_group)
        val decimalOptions = listOf(
            R.id.decimals_0 to 0,
            R.id.decimals_1 to 1,
            R.id.decimals_2 to 2,
            R.id.decimals_3 to 3
        )
        decimalOptions.forEach { (id, value) ->
            view.findViewById<RadioButton>(id).isChecked = preferences.decimals == value
        }
        decimalsGroup.setOnCheckedChangeListener { _, checkedId ->
            val value = decimalOptions.firstOrNull { it.first == checkedId }?.second
            if (value != null) preferences.decimals = value
        }

        // Keep screen on
        val keepAwake = view.findViewById<com.google.android.material.switchmaterial.SwitchMaterial>(R.id.keep_awake_switch)
        keepAwake.isChecked = preferences.keepScreenOn
        keepAwake.setOnCheckedChangeListener { _, checked -> preferences.keepScreenOn = checked }

        // History
        val historySwitch = view.findViewById<com.google.android.material.switchmaterial.SwitchMaterial>(R.id.history_switch)
        historySwitch.isChecked = preferences.historyEnabled
        historySwitch.setOnCheckedChangeListener { _, checked -> preferences.historyEnabled = checked }

        // Version
        val version = view.findViewById<TextView>(R.id.version_text)
        version.text = getString(R.string.settings_version, appVersionName())

        return view
    }

    private fun appVersionName(): String {
        val context = requireContext()
        return try {
            val info = context.packageManager.getPackageInfo(context.packageName, 0)
            info.versionName ?: "1.0.0"
        } catch (e: Exception) {
            "1.0.0"
        }
    }
}
