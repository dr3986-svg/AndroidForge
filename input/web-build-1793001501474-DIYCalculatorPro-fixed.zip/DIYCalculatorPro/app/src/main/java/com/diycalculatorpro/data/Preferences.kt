package com.diycalculatorpro.data

import android.content.Context
import android.content.SharedPreferences
import com.diycalculatorpro.engine.UnitSystem

/**
 * Application settings, stored offline in SharedPreferences.
 */
class Preferences(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    /** Unit system the user prefers to see first in unit pickers. */
    var unitSystem: UnitSystem
        get() = when (prefs.getString(KEY_UNITS, null)) {
            UnitSystem.IMPERIAL.name -> UnitSystem.IMPERIAL
            else -> UnitSystem.METRIC
        }
        set(value) {
            prefs.edit().putString(KEY_UNITS, value.name).apply()
        }

    /** Number of decimal places used when showing results. */
    var decimals: Int
        get() = prefs.getInt(KEY_DECIMALS, DEFAULT_DECIMALS).coerceIn(0, 4)
        set(value) {
            prefs.edit().putInt(KEY_DECIMALS, value.coerceIn(0, 4)).apply()
        }

    /** Whether the screen should stay on while a calculator is open. */
    var keepScreenOn: Boolean
        get() = prefs.getBoolean(KEY_KEEP_AWAKE, false)
        set(value) {
            prefs.edit().putBoolean(KEY_KEEP_AWAKE, value).apply()
        }

    /** Whether calculation history is recorded. */
    var historyEnabled: Boolean
        get() = prefs.getBoolean(KEY_HISTORY_ENABLED, true)
        set(value) {
            prefs.edit().putBoolean(KEY_HISTORY_ENABLED, value).apply()
        }

    fun registerListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    fun unregisterListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
    }

    companion object {
        private const val NAME = "diy_calculator_pro_settings"
        private const val KEY_UNITS = "unit_system"
        private const val KEY_DECIMALS = "decimals"
        private const val KEY_KEEP_AWAKE = "keep_screen_on"
        private const val KEY_HISTORY_ENABLED = "history_enabled"
        const val DEFAULT_DECIMALS = 2
    }
}
