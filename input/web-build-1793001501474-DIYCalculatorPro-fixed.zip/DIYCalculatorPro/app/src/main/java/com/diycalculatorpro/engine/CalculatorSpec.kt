package com.diycalculatorpro.engine

/**
 * Declarative description of a calculator: what it is called, which fields it
 * needs and how it turns those fields into a result.
 *
 * A [CalculatorSpec] contains no Android dependencies, so calculators can be
 * unit tested and reused freely.
 */
data class CalculatorSpec(
    val id: String,
    val titleRes: Int,
    val summaryRes: Int,
    val trade: Trade,
    val iconRes: Int,
    val fields: List<Field>,
    val calculator: CalculatorEngine
) {
    /** Stable key used for favourites and history entries. */
    val key: String get() = id

    fun numberField(id: String): NumberField? =
        fields.filterIsInstance<NumberField>().firstOrNull { it.id == id }

    fun choiceField(id: String): ChoiceField? =
        fields.filterIsInstance<ChoiceField>().firstOrNull { it.id == id }
}
