package com.diycalculatorpro.engine

/**
 * The four trades the app is built around. Each calculator belongs to one.
 */
enum class Trade(val titleRes: Int, val accentRes: Int) {
    ELECTRICAL(com.diycalculatorpro.R.string.category_electrical, com.diycalculatorpro.R.color.electric_blue),
    BUILDING(com.diycalculatorpro.R.string.category_building, com.diycalculatorpro.R.color.safety_amber),
    TILING(com.diycalculatorpro.R.string.category_tiling, com.diycalculatorpro.R.color.tile_teal),
    PAINTING(com.diycalculatorpro.R.string.category_painting, com.diycalculatorpro.R.color.paint_violet)
}
