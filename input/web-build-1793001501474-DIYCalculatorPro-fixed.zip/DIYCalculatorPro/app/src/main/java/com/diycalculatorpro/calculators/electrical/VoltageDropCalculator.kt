package com.diycalculatorpro.calculators.electrical

import com.diycalculatorpro.R
import com.diycalculatorpro.engine.CalcResult
import com.diycalculatorpro.engine.CalculatorEngine
import com.diycalculatorpro.engine.ChoiceField
import com.diycalculatorpro.engine.ChoiceOption
import com.diycalculatorpro.engine.EngineContext
import com.diycalculatorpro.engine.NumberField
import com.diycalculatorpro.engine.ResultRow
import com.diycalculatorpro.engine.Units
import com.diycalculatorpro.engine.Validate
import com.diycalculatorpro.engine.Values
import kotlin.math.sqrt

/**
 * Voltage drop along a cable run.
 *
 * Resistance is taken from the standard resistivity of the conductor at 20 °C
 * and scaled for the running temperature of the cable.
 */
object VoltageDropCalculator : CalculatorEngine {

    const val F_CURRENT = "current"
    const val F_LENGTH = "length"
    const val F_SIZE = "size"
    const val F_MATERIAL = "material"
    const val F_PHASE = "phase"

    const val MAT_COPPER = "cu"
    const val MAT_ALUMINIUM = "al"
    const val PHASE_1 = "1ph"
    const val PHASE_3 = "3ph"

    /** Resistivity at 20 °C in Ω·mm²/m. */
    private const val RHO_COPPER = 0.01724
    private const val RHO_ALUMINIUM = 0.02826

    /** Copper temperature coefficient per °C. */
    private const val ALPHA_COPPER = 0.00393
    private const val ALPHA_ALUMINIUM = 0.00403

    /** Assumed conductor running temperature for the calculation. */
    private const val RUNNING_TEMP_C = 70.0

    private val sizes = listOf(
        1.5, 2.5, 4.0, 6.0, 10.0, 16.0, 25.0, 32.0, 40.0, 50.0, 63.0, 80.0, 100.0
    )

    val fields = listOf(
        NumberField(
            id = F_CURRENT,
            labelRes = R.string.f_electrical_vd_current,
            unitOptions = listOf(Units.AMP),
            defaultUnitId = Units.AMP.id,
            allowZero = false
        ),
        NumberField(
            id = F_LENGTH,
            labelRes = R.string.f_electrical_vd_length,
            unitOptions = listOf(Units.M, Units.MM, Units.CM, Units.FOOT),
            defaultUnitId = Units.M.id,
            allowZero = false,
            helperRes = R.string.f_electrical_vd_length_helper
        ),
        ChoiceField(
            id = F_SIZE,
            labelRes = R.string.f_electrical_vd_size,
            options = sizes.map { ChoiceOption(formatSize(it), R.string.f_electrical_vd_size_opt, "${formatSize(it)} mm²") },
            defaultOptionId = formatSize(2.5)
        ),
        ChoiceField(
            id = F_MATERIAL,
            labelRes = R.string.f_electrical_vd_material,
            options = listOf(
                ChoiceOption(MAT_COPPER, R.string.opt_copper),
                ChoiceOption(MAT_ALUMINIUM, R.string.opt_aluminium)
            ),
            defaultOptionId = MAT_COPPER
        ),
        ChoiceField(
            id = F_PHASE,
            labelRes = R.string.f_electrical_vd_phase,
            options = listOf(
                ChoiceOption(PHASE_1, R.string.opt_single_phase),
                ChoiceOption(PHASE_3, R.string.opt_three_phase)
            ),
            defaultOptionId = PHASE_1
        )
    )

    private val currentField = fields.filterIsInstance<NumberField>().first { it.id == F_CURRENT }
    private val lengthField = fields.filterIsInstance<NumberField>().first { it.id == F_LENGTH }

    private fun formatSize(value: Double): String =
        if (value == Math.floor(value)) value.toInt().toString() else value.toString()

    override fun calculate(values: Values, ctx: EngineContext): CalcResult {
        Validate.requireFields(values, listOf(currentField, lengthField))?.let { return it }

        val current = values.baseValue(currentField) ?: 0.0
        val lengthM = values.baseValue(lengthField) ?: 0.0
        if (current <= 0.0) return CalcResult.error(F_CURRENT, Validate.ERR_POSITIVE)
        if (lengthM <= 0.0) return CalcResult.error(F_LENGTH, Validate.ERR_POSITIVE)

        val size = (values.choices[F_SIZE] ?: "2.5").toDoubleOrNull() ?: 2.5
        val material = values.choices[F_MATERIAL] ?: MAT_COPPER
        val phase = values.choices[F_PHASE] ?: PHASE_1

        val rho = if (material == MAT_ALUMINIUM) RHO_ALUMINIUM else RHO_COPPER
        val alpha = if (material == MAT_ALUMINIUM) ALPHA_ALUMINIUM else ALPHA_COPPER

        // Resistance of the conductor at 20 °C and at the running temperature.
        val r20 = rho * lengthM / size
        val rHot = r20 * (1.0 + alpha * (RUNNING_TEMP_C - 20.0))

        // Single phase: the loop is out and back, so double the resistance.
        val loopFactor = if (phase == PHASE_3) 1.0 else 2.0
        val drop = current * rHot * loopFactor
        val supply = if (phase == PHASE_3) 400.0 else 230.0
        val percent = drop / supply * 100.0

        val minSupply = supply - drop
        val loopLength = if (phase == PHASE_3) lengthM else lengthM * 2.0

        val rows = mutableListOf(
            ResultRow(ctx.str(R.string.f_electrical_vd_drop), ctx.withUnit(drop, Units.VOLT), emphasise = true),
            ResultRow(ctx.str(R.string.f_electrical_vd_percent), "${ctx.trim(percent, 2)}%"),
            ResultRow(ctx.str(R.string.f_electrical_vd_min_supply), ctx.withUnit(minSupply, Units.VOLT)),
            ResultRow(ctx.str(R.string.f_electrical_vd_resistance), ctx.withUnit(rHot, Units.OHM, 4)),
            ResultRow(ctx.str(R.string.f_electrical_vd_loop_length), ctx.withUnit(loopLength, Units.M))
        )

        val notes = mutableListOf<String>()
        if (percent > 5.0) {
            notes += ctx.str(R.string.f_electrical_vd_note_high)
        }
        notes += ctx.str(R.string.note_check_local)

        return CalcResult(
            headline = ctx.withUnit(drop, Units.VOLT),
            headlineLabel = ctx.str(R.string.f_electrical_vd_drop),
            rows = rows,
            notes = notes
        )
    }
}
