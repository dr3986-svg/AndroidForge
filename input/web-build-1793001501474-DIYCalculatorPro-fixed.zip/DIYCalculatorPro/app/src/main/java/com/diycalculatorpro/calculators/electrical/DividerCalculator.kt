package com.diycalculatorpro.calculators.electrical

import com.diycalculatorpro.R
import com.diycalculatorpro.engine.CalcResult
import com.diycalculatorpro.engine.CalculatorEngine
import com.diycalculatorpro.engine.EngineContext
import com.diycalculatorpro.engine.NumberField
import com.diycalculatorpro.engine.ResultRow
import com.diycalculatorpro.engine.Units
import com.diycalculatorpro.engine.Validate
import com.diycalculatorpro.engine.Values
import kotlin.math.sqrt

/**
 * Resistive voltage divider.
 *
 * Shows the unloaded output, the output with a load connected and the power
 * dissipated in each resistor so a wattage rating can be chosen.
 */
object DividerCalculator : CalculatorEngine {

    const val F_INPUT = "input"
    const val F_R1 = "r1"
    const val F_R2 = "r2"
    const val F_LOAD = "load"

    val fields = listOf(
        NumberField(
            id = F_INPUT,
            labelRes = R.string.f_electrical_divider_input,
            unitOptions = listOf(Units.VOLT),
            defaultUnitId = Units.VOLT.id,
            allowZero = false
        ),
        NumberField(
            id = F_R1,
            labelRes = R.string.f_electrical_divider_r1,
            unitOptions = listOf(Units.OHM, Units.KILOOHM, Units.MEGOHM),
            defaultUnitId = Units.KILOOHM.id,
            allowZero = false
        ),
        NumberField(
            id = F_R2,
            labelRes = R.string.f_electrical_divider_r2,
            unitOptions = listOf(Units.OHM, Units.KILOOHM, Units.MEGOHM),
            defaultUnitId = Units.KILOOHM.id,
            allowZero = false
        ),
        NumberField(
            id = F_LOAD,
            labelRes = R.string.f_electrical_divider_load,
            unitOptions = listOf(Units.OHM, Units.KILOOHM, Units.MEGOHM),
            defaultUnitId = Units.KILOOHM.id,
            required = false,
            allowZero = false,
            helperRes = R.string.f_electrical_divider_load_helper
        )
    )

    private val inputField = fields.filterIsInstance<NumberField>().first { it.id == F_INPUT }
    private val r1Field = fields.filterIsInstance<NumberField>().first { it.id == F_R1 }
    private val r2Field = fields.filterIsInstance<NumberField>().first { it.id == F_R2 }
    private val loadField = fields.filterIsInstance<NumberField>().first { it.id == F_LOAD }

    override fun calculate(values: Values, ctx: EngineContext): CalcResult {
        Validate.requireFields(values, listOf(inputField, r1Field, r2Field))?.let { return it }

        val input = values.baseValue(inputField) ?: 0.0
        val r1 = values.baseValue(r1Field) ?: 0.0
        val r2 = values.baseValue(r2Field) ?: 0.0
        if (input <= 0.0) return CalcResult.error(F_INPUT, Validate.ERR_POSITIVE)
        if (r1 <= 0.0) return CalcResult.error(F_R1, Validate.ERR_POSITIVE)
        if (r2 <= 0.0) return CalcResult.error(F_R2, Validate.ERR_POSITIVE)

        val loadRaw = values.baseValue(loadField)
        val load = loadRaw?.takeIf { it > 0.0 }

        val totalUnloaded = r1 + r2
        val vOutUnloaded = input * r2 / totalUnloaded
        val currentUnloaded = input / totalUnloaded

        val effectiveR2 = if (load != null) {
            val parallel = (r2 * load) / (r2 + load)
            parallel
        } else {
            r2
        }
        val totalLoaded = r1 + effectiveR2
        val vOutLoaded = input * effectiveR2 / totalLoaded
        val currentLoaded = input / totalLoaded

        val pR1 = currentLoaded * currentLoaded * r1
        val pR2 = currentLoaded * currentLoaded * effectiveR2
        val pLoad = if (load != null) vOutLoaded * vOutLoaded / load else 0.0

        val ratio = vOutUnloaded / input

        val rows = mutableListOf(
            ResultRow(
                ctx.str(R.string.f_electrical_divider_output),
                ctx.withUnit(vOutUnloaded, Units.VOLT),
                emphasise = true
            ),
            ResultRow(ctx.str(R.string.f_electrical_divider_ratio), ctx.trim(ratio, 4)),
            ResultRow(ctx.str(R.string.f_electrical_divider_current), ctx.withUnit(currentUnloaded, Units.MILLIAMP, 3))
        )

        if (load != null) {
            rows += ResultRow(
                ctx.str(R.string.f_electrical_divider_loaded_output),
                ctx.withUnit(vOutLoaded, Units.VOLT),
                emphasise = true
            )
            rows += ResultRow(ctx.str(R.string.f_electrical_divider_loaded_current), ctx.withUnit(currentLoaded, Units.MILLIAMP, 3))
            val sag = vOutUnloaded - vOutLoaded
            rows += ResultRow(ctx.str(R.string.f_electrical_divider_sag), ctx.withUnit(sag, Units.VOLT))
        }

        rows += ResultRow(ctx.str(R.string.f_electrical_divider_p_r1), ctx.withUnit(pR1, Units.WATT, 4))
        rows += ResultRow(ctx.str(R.string.f_electrical_divider_p_r2), ctx.withUnit(pR2, Units.WATT, 4))
        if (load != null) {
            rows += ResultRow(ctx.str(R.string.f_electrical_divider_p_load), ctx.withUnit(pLoad, Units.WATT, 4))
        }

        val notes = mutableListOf<String>()
        notes += ctx.str(R.string.f_electrical_divider_note_wattage)

        return CalcResult(
            headline = ctx.withUnit(vOutUnloaded, Units.VOLT),
            headlineLabel = ctx.str(R.string.f_electrical_divider_output),
            rows = rows,
            notes = notes
        )
    }
}
