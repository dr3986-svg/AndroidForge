package com.diycalculatorpro.ui.list

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.diycalculatorpro.R
import com.diycalculatorpro.data.HistoryEntry
import com.diycalculatorpro.ui.Services
import com.diycalculatorpro.ui.calculator.CalculatorActivity

/**
 * The list of previously saved calculations.
 */
class HistoryFragment : Fragment() {

    private lateinit var adapter: HistoryAdapter
    private lateinit var emptyView: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_history, container, false)

        emptyView = view.findViewById(R.id.empty_message)
        val list = view.findViewById<RecyclerView>(R.id.history_list)
        val clearButton = view.findViewById<View>(R.id.clear_button)

        adapter = HistoryAdapter(
            onClick = { entry ->
                CalculatorRegistryLookup.open(requireContext(), entry.calculatorId)
            },
            onDelete = { entry ->
                Services.history(requireContext()).remove(entry.id)
                refresh()
            }
        )
        list.layoutManager = LinearLayoutManager(requireContext())
        list.adapter = adapter

        clearButton.setOnClickListener { confirmClear() }

        return view
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val entries = Services.history(requireContext()).all()
        adapter.submit(entries)
        emptyView.visibility = if (entries.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun confirmClear() {
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.clear_history_confirm)
            .setMessage(R.string.clear_history_confirm_body)
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.clear) { _, _ ->
                Services.history(requireContext()).clear()
                refresh()
            }
            .show()
    }
}

/**
 * Opens a calculator from a history entry.
 */
object CalculatorRegistryLookup {
    fun open(context: android.content.Context, calculatorId: String) {
        com.diycalculatorpro.calculators.CalculatorRegistry.find(calculatorId) ?: return
        context.startActivity(CalculatorActivity.intent(context, calculatorId))
    }
}
