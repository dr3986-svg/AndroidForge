package com.diycalculatorpro.data

import android.content.Context
import org.json.JSONArray

/**
 * Stores the user's favourite calculators.
 *
 * The list is kept as a JSON array of calculator ids so the order the user
 * added them in is preserved. Everything stays on the device.
 */
class FavouritesStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences(NAME, Context.MODE_PRIVATE)

    /** Favourite calculator ids, most recently added first. */
    fun all(): List<String> {
        val raw = prefs.getString(KEY_IDS, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).map { array.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun isFavourite(calculatorId: String): Boolean = all().contains(calculatorId)

    /** Adds the id if missing. Returns true when the list changed. */
    fun add(calculatorId: String): Boolean {
        val current = all().toMutableList()
        if (current.contains(calculatorId)) return false
        current.add(0, calculatorId)
        write(current)
        return true
    }

    /** Removes the id if present. Returns true when the list changed. */
    fun remove(calculatorId: String): Boolean {
        val current = all().toMutableList()
        if (!current.remove(calculatorId)) return false
        write(current)
        return true
    }

    /** Adds the id when missing, removes it when present. */
    fun toggle(calculatorId: String): Boolean {
        return if (isFavourite(calculatorId)) {
            remove(calculatorId)
            false
        } else {
            add(calculatorId)
            true
        }
    }

    fun clear() {
        prefs.edit().remove(KEY_IDS).apply()
    }

    private fun write(ids: List<String>) {
        val array = JSONArray()
        ids.forEach { array.put(it) }
        prefs.edit().putString(KEY_IDS, array.toString()).apply()
    }

    companion object {
        private const val NAME = "diy_calculator_pro_favourites"
        private const val KEY_IDS = "favourite_ids"
    }
}
