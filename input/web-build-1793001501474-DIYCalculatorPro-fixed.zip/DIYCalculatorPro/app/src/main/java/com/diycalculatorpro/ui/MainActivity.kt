package com.diycalculatorpro.ui

import android.os.Bundle
import android.view.MenuItem
import android.widget.FrameLayout
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import com.diycalculatorpro.R
import com.diycalculatorpro.ui.list.CalculatorsFragment
import com.diycalculatorpro.ui.list.FavouritesFragment
import com.diycalculatorpro.ui.list.HistoryFragment
import com.diycalculatorpro.ui.list.SettingsFragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.snackbar.Snackbar

/**
 * The single activity that hosts the four main sections.
 */
class MainActivity : androidx.appcompat.app.AppCompatActivity() {

    private lateinit var bottomNav: BottomNavigationView
    private lateinit var content: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        content = findViewById(R.id.fragment_container)
        bottomNav = findViewById(R.id.bottom_nav)

        bottomNav.setOnItemSelectedListener { item: MenuItem ->
            showSection(item.itemId)
            true
        }
        bottomNav.setOnItemReselectedListener { /* no-op */ }

        if (savedInstanceState == null) {
            bottomNav.selectedItemId = R.id.nav_calculators
        }
    }

    private fun showSection(itemId: Int) {
        val fragment: Fragment = when (itemId) {
            R.id.nav_favourites -> FavouritesFragment()
            R.id.nav_history -> HistoryFragment()
            R.id.nav_settings -> SettingsFragment()
            else -> CalculatorsFragment()
        }
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
            .commit()
    }

    /** Shows a transient message at the bottom of the screen. */
    fun toast(message: CharSequence) {
        Snackbar.make(content, message, Snackbar.LENGTH_SHORT).show()
    }
}
