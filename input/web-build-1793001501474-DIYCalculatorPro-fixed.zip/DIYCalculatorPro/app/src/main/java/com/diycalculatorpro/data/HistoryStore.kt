package com.diycalculatorpro.data

import android.content.Context
import org.json.JSONArray

/**
 * Stores the calculation history.
 *
 * The history is capped at [MAX_ENTRIES] so the stored JSON never grows
 * without bound. All data stays on the device — nothing is uploaded.
 */
class HistoryStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences(NAME, Context.MODE_PRIVATE)

    /** All stored entries, newest first. */
    fun all(): List<HistoryEntry> {
        val raw = prefs.getString(KEY_ENTRIES, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { i ->
                HistoryEntry.fromJson(array.optJSONObject(i) ?: return@mapNotNull null)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Adds an entry to the top of the list. */
    fun add(entry: HistoryEntry) {
        val updated = (listOf(entry) + all()).take(MAX_ENTRIES)
        write(updated)
    }

    /** Removes the entry with the given id. */
    fun remove(id: Long) {
        val updated = all().filterNot { it.id == id }
        write(updated)
    }

    fun clear() {
        prefs.edit().remove(KEY_ENTRIES).apply()
    }

    /** Entries recorded for one calculator, newest first. */
    fun forCalculator(calculatorId: String): List<HistoryEntry> =
        all().filter { it.calculatorId == calculatorId }

    private fun write(entries: List<HistoryEntry>) {
        val array = JSONArray()
        entries.forEach { array.put(it.toJson()) }
        prefs.edit().putString(KEY_ENTRIES, array.toString()).apply()
    }

    companion object {
        private const val NAME = "diy_calculator_pro_history"
        private const val KEY_ENTRIES = "entries"

        /** Maximum number of entries kept on the device. */
        const val MAX_ENTRIES = 200
    }
}
