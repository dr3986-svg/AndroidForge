package com.diycalculatorpro.calculators.electrical

import com.diycalculatorpro.R
import com.diycalculatorpro.engine.CalcResult
import com.diycalculatorpro.engine.CalculatorEngine
import com.diycalculatorpro.engine.ChoiceField
import com.diycalculatorpro.engine.ChoiceOption
import com.diycalculatorpro.engine.EngineContext
import com.diycalculatorpro.engine.NumberField
import com.diycalculatorpro.engine.ResultRow
import com.diycalculatorpro.engine.Units
import com.diycalculatorpro.engine.Validate
import com.diycalculatorpro.engine.Values
import kotlin.math.abs

/**
 * Ohm's Law: V = I x R.
 *
 * The user picks which quantity to solve for; the other two are required and
 * the solved field is ignored if it has been filled in.
 */
object OhmLawCalculator : CalculatorEngine {

    const val F_SOLVE = "solve"
    const val F_VOLTAGE = "voltage"
    const val F_CURRENT = "current"
    const val F_RESISTANCE = "resistance"

    const val SOLVE_VOLTAGE = "v"
    const val SOLVE_CURRENT = "i"
    const val SOLVE_RESISTANCE = "r"

    val fields = listOf(
        ChoiceField(
            id = F_SOLVE,
            labelRes = R.string.f_electrical_ohm_solve,
            options = listOf(
                ChoiceOption(SOLVE_VOLTAGE, R.string.opt_voltage),
                ChoiceOption(SOLVE_CURRENT, R.string.opt_current),
                ChoiceOption(SOLVE_RESISTANCE, R.string.opt_resistance)
            ),
            defaultOptionId = SOLVE_VOLTAGE
        ),
        NumberField(
            id = F_VOLTAGE,
            labelRes = R.string.f_electrical_ohm_voltage,
            unitOptions = listOf(Units.VOLT, Units.MILLIVOLT, Units.KILOVOLT),
            defaultUnitId = Units.VOLT.id,
            allowZero = false,
            helperRes = R.string.f_electrical_ohm_voltage_helper
        ),
        NumberField(
            id = F_CURRENT,
            labelRes = R.string.f_electrical_ohm_current,
            unitOptions = listOf(Units.AMP, Units.MILLIAMP, Units.KILOAMP),
            defaultUnitId = Units.AMP.id,
            allowZero = false,
            helperRes = R.string.f_electrical_ohm_current_helper
        ),
        NumberField(
            id = F_RESISTANCE,
            labelRes = R.string.f_electrical_ohm_resistance,
            unitOptions = listOf(Units.OHM, Units.KILOOHM, Units.MEGOHM),
            defaultUnitId = Units.OHM.id,
            allowZero = false,
            helperRes = R.string.f_electrical_ohm_resistance_helper
        )
    )

    private val voltageField = fields.filterIsInstance<NumberField>().first { it.id == F_VOLTAGE }
    private val currentField = fields.filterIsInstance<NumberField>().first { it.id == F_CURRENT }
    private val resistanceField = fields.filterIsInstance<NumberField>().first { it.id == F_RESISTANCE }

    override fun calculate(values: Values, ctx: EngineContext): CalcResult {
        val solve = values.choices[F_SOLVE] ?: SOLVE_VOLTAGE

        // Only the two known quantities are required.
        val required: List<NumberField> = when (solve) {
            SOLVE_CURRENT -> listOf(voltageField, resistanceField)
            SOLVE_RESISTANCE -> listOf(voltageField, currentField)
            else -> listOf(currentField, resistanceField)
        }
        Validate.requireFields(values, required)?.let { return it }

        val voltage = values.baseValue(voltageField) ?: 0.0
        val current = values.baseValue(currentField) ?: 0.0
        val resistance = values.baseValue(resistanceField) ?: 0.0

        if (resistance == 0.0 && solve != SOLVE_RESISTANCE) {
            return CalcResult.error(F_RESISTANCE, Validate.ERR_NOT_ZERO)
        }
        if (voltage == 0.0 && solve == SOLVE_CURRENT) {
            return CalcResult.error(F_VOLTAGE, Validate.ERR_NOT_ZERO)
        }
        if (current == 0.0 && solve == SOLVE_RESISTANCE) {
            return CalcResult.error(F_CURRENT, Validate.ERR_NOT_ZERO)
        }

        val solvedVoltage: Double
        val solvedCurrent: Double
        val solvedResistance: Double

        when (solve) {
            SOLVE_CURRENT -> {
                solvedCurrent = voltage / resistance
                solvedVoltage = voltage
                solvedResistance = resistance
            }
            SOLVE_RESISTANCE -> {
                solvedResistance = voltage / current
                solvedVoltage = voltage
                solvedCurrent = current
            }
            else -> {
                solvedVoltage = current * resistance
                solvedCurrent = current
                solvedResistance = resistance
            }
        }

        if (!solvedVoltage.isFinite() || !solvedCurrent.isFinite() || !solvedResistance.isFinite()) {
            return CalcResult.error(null, Validate.ERR_MATH)
        }

        val rows = mutableListOf<ResultRow>()

        val headlineValue = when (solve) {
            SOLVE_CURRENT -> solvedCurrent
            SOLVE_RESISTANCE -> solvedResistance
            else -> solvedVoltage
        }
        val headlineUnit = when (solve) {
            SOLVE_CURRENT -> Units.AMP
            SOLVE_RESISTANCE -> Units.OHM
            else -> Units.VOLT
        }
        val headlineLabel = when (solve) {
            SOLVE_CURRENT -> ctx.str(R.string.opt_current)
            SOLVE_RESISTANCE -> ctx.str(R.string.opt_resistance)
            else -> ctx.str(R.string.opt_voltage)
        }

        rows += ResultRow(
            ctx.str(R.string.opt_voltage),
            ctx.withUnit(solvedVoltage, Units.VOLT),
            emphasise = solve == SOLVE_VOLTAGE
        )
        rows += ResultRow(
            ctx.str(R.string.opt_current),
            ctx.withUnit(solvedCurrent, Units.AMP),
            emphasise = solve == SOLVE_CURRENT
        )
        rows += ResultRow(
            ctx.str(R.string.opt_resistance),
            ctx.withUnit(solvedResistance, Units.OHM),
            emphasise = solve == SOLVE_RESISTANCE
        )

        val power = solvedVoltage * solvedCurrent
        if (abs(power) > 0.0 && power.isFinite()) {
            rows += ResultRow(ctx.str(R.string.r_power), ctx.withUnit(power, Units.WATT))
        }

        return CalcResult(
            headline = ctx.withUnit(headlineValue, headlineUnit),
            headlineLabel = headlineLabel,
            rows = rows
        )
    }
}
