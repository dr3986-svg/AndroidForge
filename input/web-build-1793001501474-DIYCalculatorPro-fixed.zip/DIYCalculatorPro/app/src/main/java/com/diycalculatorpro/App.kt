package com.diycalculatorpro

import android.app.Application
import com.diycalculatorpro.calculators.CalculatorRegistry
import com.diycalculatorpro.data.FavouritesStore
import com.diycalculatorpro.data.HistoryStore
import com.diycalculatorpro.data.Preferences

/**
 * Application entry point.
 *
 * Holds the app-wide singletons so fragments and activities can reach the
 * stores without pulling in a dependency injection framework.
 */
class App : Application() {

    lateinit var preferences: Preferences
        private set

    lateinit var favourites: FavouritesStore
        private set

    lateinit var history: HistoryStore
        private set

    override fun onCreate() {
        super.onCreate()
        preferences = Preferences(this)
        favourites = FavouritesStore(this)
        history = HistoryStore(this)
        // Prime the search cache so calculator search works without Resources.
        CalculatorRegistry.primeSearchCache(resources)
    }
}
