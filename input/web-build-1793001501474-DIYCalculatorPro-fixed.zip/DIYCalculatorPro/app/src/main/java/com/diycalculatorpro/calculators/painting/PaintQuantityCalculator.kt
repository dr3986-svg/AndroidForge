package com.diycalculatorpro.calculators.painting

import com.diycalculatorpro.R
import com.diycalculatorpro.engine.CalcResult
import com.diycalculatorpro.engine.CalculatorEngine
import com.diycalculatorpro.engine.ChoiceField
import com.diycalculatorpro.engine.ChoiceOption
import com.diycalculatorpro.engine.EngineContext
import com.diycalculatorpro.engine.NumberField
import com.diycalculatorpro.engine.ResultRow
import com.diycalculatorpro.engine.Units
import com.diycalculatorpro.engine.Validate
import com.diycalculatorpro.engine.Values
import kotlin.math.ceil

/**
 * Paint quantity for an area and number of coats.
 *
 * Coverage rates are the typical figures printed on paint tins; the waste
 * allowance covers cutting in, spillage and touch-ins.
 */
object PaintQuantityCalculator : CalculatorEngine {

    const val F_AREA = "area"
    const val F_COATS = "coats"
    const val F_TYPE = "type"
    const val F_WASTE = "waste"
    const val F_TIN = "tin"

    /** Coverage in m² per litre. */
    private val coverage = mapOf(
        "emulsion" to 10.0,
        "eggshell" to 12.0,
        "gloss" to 14.0,
        "primer" to 10.0,
        "masonry" to 8.0
    )

    private val tinSizes = mapOf(
        "1" to 1.0,
        "2.5" to 2.5,
        "5" to 5.0,
        "15" to 15.0
    )

    val fields = listOf(
        NumberField(
            id = F_AREA,
            labelRes = R.string.f_painting_quantity_area,
            unitOptions = listOf(Units.M2, Units.FT2),
            defaultUnitId = Units.M2.id,
            allowZero = false
        ),
        NumberField(
            id = F_COATS,
            labelRes = R.string.f_painting_quantity_coats,
            min = 1.0,
            max = 10.0,
            helperRes = R.string.f_painting_quantity_coats_helper
        ),
        ChoiceField(
            id = F_TYPE,
            labelRes = R.string.f_painting_quantity_type,
            options = listOf(
                ChoiceOption("emulsion", R.string.opt_paint_emulsion),
                ChoiceOption("eggshell", R.string.opt_paint_eggshell),
                ChoiceOption("gloss", R.string.opt_paint_gloss),
                ChoiceOption("primer", R.string.opt_paint_primer),
                ChoiceOption("masonry", R.string.opt_paint_masonry)
            ),
            defaultOptionId = "emulsion"
        ),
        NumberField(
            id = F_WASTE,
            labelRes = R.string.f_painting_quantity_waste,
            min = 0.0,
            max = 50.0,
            helperRes = R.string.f_painting_quantity_waste_helper
        ),
        ChoiceField(
            id = F_TIN,
            labelRes = R.string.f_painting_quantity_tin,
            options = listOf(
                ChoiceOption("1", R.string.opt_tin_1),
                ChoiceOption("2.5", R.string.opt_tin_2_5),
                ChoiceOption("5", R.string.opt_tin_5),
                ChoiceOption("15", R.string.opt_tin_15)
            ),
            defaultOptionId = "2.5"
        )
    )

    private val areaField = fields.filterIsInstance<NumberField>().first { it.id == F_AREA }
    private val coatsField = fields.filterIsInstance<NumberField>().first { it.id == F_COATS }
    private val wasteField = fields.filterIsInstance<NumberField>().first { it.id == F_WASTE }

    override fun calculate(values: Values, ctx: EngineContext): CalcResult {
        Validate.requireFields(values, listOf(areaField, coatsField))?.let { return it }

        val area = values.baseValue(areaField) ?: 0.0
        if (area <= 0.0) return CalcResult.error(F_AREA, Validate.ERR_POSITIVE)

        val coats = values.numbers[coatsField.id] ?: 2.0
        val type = values.choices[F_TYPE] ?: "emulsion"
        val wastePercent = values.numbers[wasteField.id] ?: 10.0
        val tinSize = tinSizes[values.choices[F_TIN] ?: "2.5"] ?: 2.5
        val coverRate = coverage[type] ?: 10.0

        val litresPerCoat = area / coverRate
        val litresTotal = litresPerCoat * coats
        val litresWithWaste = litresTotal * (1.0 + wastePercent / 100.0)
        val tins = ceil(litresWithWaste / tinSize)
        val litresNeeded = tins * tinSize

        val rows = mutableListOf(
            ResultRow(
                ctx.str(R.string.f_painting_quantity_litres),
                "${ctx.trim(litresWithWaste, 1)} L",
                emphasise = true
            ),
            ResultRow(
                ctx.str(R.string.f_painting_quantity_tins),
                "$tins × ${ctx.trim(tinSize, 1)} L",
                emphasise = true
            ),
            ResultRow(ctx.str(R.string.f_painting_quantity_total_paint), "${ctx.trim(litresNeeded, 1)} L"),
            ResultRow(ctx.str(R.string.f_painting_quantity_per_coat), "${ctx.trim(litresPerCoat, 1)} L"),
            ResultRow(ctx.str(R.string.f_painting_quantity_coverage_rate), "${ctx.trim(coverRate, 1)} m²/L")
        )

        val notes = mutableListOf<String>()
        notes += ctx.str(R.string.f_painting_quantity_note_coverage)
        notes += ctx.str(R.string.note_check_manufacturer)

        return CalcResult(
            headline = "${ctx.trim(litresWithWaste, 1)} L",
            headlineLabel = ctx.str(R.string.f_painting_quantity_litres),
            rows = rows,
            notes = notes
        )
    }
}
