package com.diycalculatorpro.ui.calculator

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.diycalculatorpro.R
import com.diycalculatorpro.calculators.CalculatorRegistry
import com.diycalculatorpro.data.HistoryEntry
import com.diycalculatorpro.engine.CalcResult
import com.diycalculatorpro.engine.CalculatorSpec
import com.diycalculatorpro.engine.EngineContext
import com.diycalculatorpro.ui.Services
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView

/**
 * Hosts a single calculator: the input form, the calculate button and the
 * result panel.
 */
class CalculatorActivity : AppCompatActivity() {

    private lateinit var spec: CalculatorSpec
    private lateinit var renderer: FieldRenderer

    private lateinit var resultCard: MaterialCardView
    private lateinit var resultLabel: TextView
    private lateinit var resultValue: TextView
    private lateinit var resultRows: LinearLayout
    private lateinit var resultNotes: TextView
    private lateinit var calculateButton: MaterialButton

    private var lastResult: CalcResult? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculator)

        val calculatorId = intent.getStringExtra(EXTRA_CALCULATOR_ID)
        val found = calculatorId?.let { CalculatorRegistry.find(it) }
        if (found == null) {
            finish()
            return
        }
        spec = found

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = getString(spec.titleRes)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        resultCard = findViewById(R.id.result_card)
        resultLabel = findViewById(R.id.result_label)
        resultValue = findViewById(R.id.result_value)
        resultRows = findViewById(R.id.result_rows)
        resultNotes = findViewById(R.id.result_notes)
        calculateButton = findViewById(R.id.calculate_button)

        renderer = FieldRenderer(
            activity = this,
            container = findViewById(R.id.fields_container),
            spec = spec,
            onChanged = { calculateButton.isEnabled = true }
        )
        renderer.build()

        calculateButton.setOnClickListener { calculate() }

        if (Services.preferences(this).keepScreenOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_calculator, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val favourite = menu.findItem(R.id.action_favourite)
        val isFavourite = Services.favourites(this).isFavourite(spec.id)
        favourite?.setIcon(if (isFavourite) R.drawable.ic_star_filled else R.drawable.ic_star_outline)
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_favourite -> {
                val store = Services.favourites(this)
                val nowFavourite = store.toggle(spec.id)
                invalidateOptionsMenu()
                toast(
                    getString(
                        if (nowFavourite) R.string.added_to_favourites
                        else R.string.removed_from_favourites
                    )
                )
                true
            }
            R.id.action_copy -> {
                copyResult()
                true
            }
            R.id.action_clear -> {
                renderer.clear()
                hideResult()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun calculate() {
        val preferences = Services.preferences(this)
        val ctx = EngineContext(
            res = resources,
            unitSystem = preferences.unitSystem,
            decimals = preferences.decimals
        )

        val values = renderer.currentValues()
        val result = try {
            spec.calculator.calculate(values, ctx)
        } catch (e: Exception) {
            CalcResult.error(null, getString(R.string.err_math))
        }

        lastResult = result
        renderer.showError(result.errorFieldId, result.errorMessage)

        if (result.isError) {
            resultCard.visibility = View.VISIBLE
            resultLabel.text = getString(R.string.result_error)
            resultValue.text = result.errorMessage.orEmpty()
            resultRows.removeAllViews()
            resultNotes.text = ""
            resultNotes.visibility = View.GONE
            return
        }

        showResult(result)
        saveToHistory(result)
    }

    private fun showResult(result: CalcResult) {
        resultCard.visibility = View.VISIBLE
        resultLabel.text = result.headlineLabel
        resultValue.text = result.headline

        resultRows.removeAllViews()
        val inflater = layoutInflater
        result.rows.forEach { row ->
            val view = inflater.inflate(R.layout.item_result_row, resultRows, false)
            view.findViewById<TextView>(R.id.row_label).text = row.label
            val valueView = view.findViewById<TextView>(R.id.row_value)
            valueView.text = row.value
            if (row.emphasise) {
                valueView.setTextColor(
                    com.google.android.material.color.MaterialColors.getColor(
                        valueView,
                        com.google.android.material.R.attr.colorPrimary
                    )
                )
            }
            resultRows.addView(view)
        }

        if (result.notes.isEmpty()) {
            resultNotes.visibility = View.GONE
        } else {
            resultNotes.visibility = View.VISIBLE
            resultNotes.text = result.notes.joinToString("\n") { "• $it" }
        }
    }

    private fun hideResult() {
        resultCard.visibility = View.GONE
        lastResult = null
    }

    private fun saveToHistory(result: CalcResult) {
        val preferences = Services.preferences(this)
        if (!preferences.historyEnabled) return

        val entry = HistoryEntry(
            id = System.currentTimeMillis(),
            calculatorId = spec.id,
            calculatorTitle = getString(spec.titleRes),
            headlineLabel = result.headlineLabel,
            headline = result.headline,
            rows = result.rows.map { row -> row.label to row.value },
            timestamp = System.currentTimeMillis()
        )
        Services.history(this).add(entry)
    }

    private fun copyResult() {
        val result = lastResult ?: return
        val text = buildString {
            append(getString(spec.titleRes))
            append('\n')
            append(result.headlineLabel)
            append(": ")
            append(result.headline)
            result.rows.forEach { row ->
                append('\n')
                append(row.label)
                append(": ")
                append(row.value)
            }
        }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        clipboard?.setPrimaryClip(ClipData.newPlainText(getString(spec.titleRes), text))
        toast(getString(R.string.copied_to_clipboard))
    }

    private fun toast(message: CharSequence) {
        com.google.android.material.snackbar.Snackbar
            .make(findViewById(R.id.root), message, com.google.android.material.snackbar.Snackbar.LENGTH_SHORT)
            .show()
    }

    companion object {
        private const val EXTRA_CALCULATOR_ID = "calculator_id"

        fun intent(context: Context, calculatorId: String): Intent =
            Intent(context, CalculatorActivity::class.java)
                .putExtra(EXTRA_CALCULATOR_ID, calculatorId)
    }
}
