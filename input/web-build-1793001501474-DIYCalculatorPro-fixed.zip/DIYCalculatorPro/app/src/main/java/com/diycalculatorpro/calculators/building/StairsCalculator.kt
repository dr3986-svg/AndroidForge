package com.diycalculatorpro.calculators.building

import com.diycalculatorpro.R
import com.diycalculatorpro.engine.CalcResult
import com.diycalculatorpro.engine.CalculatorEngine
import com.diycalculatorpro.engine.EngineContext
import com.diycalculatorpro.engine.NumberField
import com.diycalculatorpro.engine.ResultRow
import com.diycalculatorpro.engine.Units
import com.diycalculatorpro.engine.Validate
import com.diycalculatorpro.engine.Values
import kotlin.math.atan2

/**
 * Stair geometry.
 *
 * The user enters the floor-to-floor height and either the number of risers or
 * the target going; the calculator reports the other dimension plus the
 * pitch angle and the Blondel comfort check.
 */
object StairsCalculator : CalculatorEngine {

    const val F_RISE = "rise"
    const val F_GOING = "going"
    const val F_RISERS = "risers"

    /** Comfortable range for the Blondel rule 2R + G. */
    private const val BLONDEL_MIN = 600.0
    private const val BLONDEL_MAX = 640.0

    /** Maximum riser height allowed in most residential codes. */
    private const val MAX_RISER_MM = 190.0
    private const val MIN_RISER_MM = 150.0

    val fields = listOf(
        NumberField(
            id = F_RISE,
            labelRes = R.string.f_building_stairs_rise,
            unitOptions = listOf(Units.MM, Units.CM, Units.M, Units.FOOT, Units.INCH),
            defaultUnitId = Units.MM.id,
            allowZero = false
        ),
        NumberField(
            id = F_GOING,
            labelRes = R.string.f_building_stairs_going,
            unitOptions = listOf(Units.MM, Units.CM, Units.M, Units.INCH),
            defaultUnitId = Units.MM.id,
            required = false,
            allowZero = false,
            helperRes = R.string.f_building_stairs_going_helper
        ),
        NumberField(
            id = F_RISERS,
            labelRes = R.string.f_building_stairs_risers,
            min = 1.0,
            max = 60.0,
            helperRes = R.string.f_building_stairs_risers_helper
        )
    )

    private val riseField = fields.filterIsInstance<NumberField>().first { it.id == F_RISE }
    private val goingField = fields.filterIsInstance<NumberField>().first { it.id == F_GOING }
    private val risersField = fields.filterIsInstance<NumberField>().first { it.id == F_RISERS }

    override fun calculate(values: Values, ctx: EngineContext): CalcResult {
        Validate.requireFields(values, listOf(riseField))?.let { return it }

        val totalRiseM = values.baseValue(riseField) ?: 0.0
        if (totalRiseM <= 0.0) return CalcResult.error(F_RISE, Validate.ERR_POSITIVE)

        val risersRaw = values.numbers[risersField.id]
        val goingRaw = values.baseValue(goingField)

        // Either a riser count or a going must be supplied.
        if (risersRaw == null && goingRaw == null) {
            return CalcResult.error(F_RISERS, Validate.ERR_REQUIRED)
        }

        var risers: Int
        var going: Double
        var riser: Double

        if (risersRaw != null) {
            risers = Math.round(risersRaw).toInt().coerceAtLeast(1)
            riser = totalRiseM * 1000.0 / risers
            going = goingRaw ?: defaultGoing(riser)
        } else {
            going = goingRaw ?: 0.0
            // Pick the riser count that gives the closest whole-number rise.
            val idealRisers = totalRiseM * 1000.0 / (going)
            risers = Math.round(idealRisers).toInt().coerceAtLeast(1)
            riser = totalRiseM * 1000.0 / risers
        }

        if (going <= 0.0) return CalcResult.error(F_GOING, Validate.ERR_POSITIVE)

        val treads = risers - 1
        val totalGoing = going * treads
        val angle = Math.toDegrees(atan2(riser, going))
        val blondel = 2.0 * riser + going
        val pitchLength = Math.hypot(riser, going) * risers
        val floorArea = totalGoing * risers * 0.5

        val rows = mutableListOf(
            ResultRow(ctx.str(R.string.f_building_stairs_riser), "${ctx.trim(riser, 1)} mm", emphasise = true),
            ResultRow(ctx.str(R.string.f_building_stairs_going_out), "${ctx.trim(going, 1)} mm", emphasise = true),
            ResultRow(ctx.str(R.string.f_building_stairs_risers_out), "${risers} (${treads} treads)"),
            ResultRow(ctx.str(R.string.f_building_stairs_total_going), "${ctx.trim(totalGoing, 0)} mm"),
            ResultRow(ctx.str(R.string.f_building_stairs_angle), "${ctx.trim(angle, 1)}°"),
            ResultRow(ctx.str(R.string.f_building_stairs_pitch_length), "${ctx.trim(pitchLength, 0)} mm"),
            ResultRow(ctx.str(R.string.f_building_stairs_floor_area), ctx.withUnit(floorArea, Units.M2))
        )

        val notes = mutableListOf<String>()
        if (blondel in BLONDEL_MIN..BLONDEL_MAX) {
            notes += ctx.str(R.string.f_building_stairs_note_comfortable)
        } else {
            notes += ctx.str(R.string.f_building_stairs_note_check)
        }
        if (riser > MAX_RISER_MM) {
            notes += ctx.str(R.string.f_building_stairs_note_riser_high)
        }
        if (riser < MIN_RISER_MM) {
            notes += ctx.str(R.string.f_building_stairs_note_riser_low)
        }
        notes += ctx.str(R.string.note_check_local)

        return CalcResult(
            headline = "${ctx.trim(riser, 1)} mm",
            headlineLabel = ctx.str(R.string.f_building_stairs_riser),
            rows = rows,
            notes = notes
        )
    }

    /** A comfortable going for the given riser, following the 2R + G rule. */
    private fun defaultGoing(riser: Double): Double {
        val target = BLONDEL_MAX - 2.0 * riser
        return target.coerceIn(200.0, 300.0)
    }
}
