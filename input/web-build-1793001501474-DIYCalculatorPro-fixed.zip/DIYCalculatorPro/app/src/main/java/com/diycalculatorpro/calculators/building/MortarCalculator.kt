package com.diycalculatorpro.calculators.building

import com.diycalculatorpro.R
import com.diycalculatorpro.engine.CalcResult
import com.diycalculatorpro.engine.CalculatorEngine
import com.diycalculatorpro.engine.ChoiceField
import com.diycalculatorpro.engine.ChoiceOption
import com.diycalculatorpro.engine.EngineContext
import com.diycalculatorpro.engine.NumberField
import com.diycalculatorpro.engine.ResultRow
import com.diycalculatorpro.engine.Units
import com.diycalculatorpro.engine.Validate
import com.diycalculatorpro.engine.Values
import kotlin.math.ceil

/**
 * Mortar and render quantities for a chosen mix ratio.
 *
 * Mix ratios are given as cement to sand by volume. The dry volume is taken as
 * 1.25 times the wet volume, which is the usual site allowance.
 */
object MortarCalculator : CalculatorEngine {

    const val F_AREA = "area"
    const val F_THICKNESS = "thickness"
    const val F_MIX = "mix"
    const val F_TYPE = "type"

    const val TYPE_MORTAR = "mortar"
    const val TYPE_RENDER = "render"

    /** Cement kg and sand kg per m³ of wet mortar, for each mix ratio. */
    private val mixes = mapOf(
        "1:3" to Pair(300.0, 1200.0),
        "1:4" to Pair(230.0, 920.0),
        "1:5" to Pair(192.0, 768.0),
        "1:6" to Pair(161.0, 644.0),
        "1:8" to Pair(122.0, 488.0)
    )

    val fields = listOf(
        NumberField(
            id = F_AREA,
            labelRes = R.string.f_building_mortar_area,
            unitOptions = listOf(Units.M2, Units.FT2),
            defaultUnitId = Units.M2.id,
            allowZero = false
        ),
        NumberField(
            id = F_THICKNESS,
            labelRes = R.string.f_building_mortar_thickness,
            unitOptions = listOf(Units.MM, Units.CM, Units.INCH),
            defaultUnitId = Units.MM.id,
            allowZero = false,
            helperRes = R.string.f_building_mortar_thickness_helper
        ),
        ChoiceField(
            id = F_MIX,
            labelRes = R.string.f_building_mortar_mix,
            options = listOf(
                ChoiceOption("1:3", R.string.opt_mix_1_3),
                ChoiceOption("1:4", R.string.opt_mix_1_4),
                ChoiceOption("1:5", R.string.opt_mix_1_5),
                ChoiceOption("1:6", R.string.opt_mix_1_6),
                ChoiceOption("1:8", R.string.opt_mix_1_8)
            ),
            defaultOptionId = "1:4"
        ),
        ChoiceField(
            id = F_TYPE,
            labelRes = R.string.f_building_mortar_type,
            options = listOf(
                ChoiceOption(TYPE_MORTAR, R.string.opt_render_mortar),
                ChoiceOption(TYPE_RENDER, R.string.opt_render_render)
            ),
            defaultOptionId = TYPE_MORTAR
        )
    )

    private val areaField = fields.filterIsInstance<NumberField>().first { it.id == F_AREA }
    private val thicknessField = fields.filterIsInstance<NumberField>().first { it.id == F_THICKNESS }

    override fun calculate(values: Values, ctx: EngineContext): CalcResult {
        Validate.requireFields(values, listOf(areaField, thicknessField))?.let { return it }

        val area = values.baseValue(areaField) ?: 0.0
        val thickness = values.baseValue(thicknessField) ?: 0.0
        if (area <= 0.0) return CalcResult.error(F_AREA, Validate.ERR_POSITIVE)
        if (thickness <= 0.0) return CalcResult.error(F_THICKNESS, Validate.ERR_POSITIVE)

        val mixId = values.choices[F_MIX] ?: "1:4"
        val type = values.choices[F_TYPE] ?: TYPE_MORTAR
        val (cementPerM3, sandPerM3) = mixes[mixId] ?: mixes.getValue("1:4")

        val wetVolume = area * thickness
        val cementKg = wetVolume * cementPerM3
        val sandKg = wetVolume * sandPerM3
        val waterLitres = cementKg * 0.48

        val cementBags = ceil(cementKg / 25.0)
        val sandBags = ceil(sandKg / 25.0)

        val rows = mutableListOf(
            ResultRow(ctx.str(R.string.f_building_mortar_volume), ctx.withUnit(wetVolume, Units.M3, 3)),
            ResultRow(
                ctx.str(R.string.f_building_mortar_cement),
                "${ctx.trim(cementBags, 0)} bags (${ctx.trim(cementKg, 0)} kg)",
                emphasise = true
            ),
            ResultRow(
                ctx.str(R.string.f_building_mortar_sand),
                "${ctx.trim(sandBags, 0)} bags (${ctx.trim(sandKg, 0)} kg)",
                emphasise = true
            ),
            ResultRow(ctx.str(R.string.f_building_mortar_water), "${ctx.trim(waterLitres, 0)} L")
        )

        val notes = mutableListOf<String>()
        if (type == TYPE_RENDER) {
            notes += ctx.str(R.string.f_building_mortar_note_render)
        }
        notes += ctx.str(R.string.note_check_manufacturer)

        return CalcResult(
            headline = "${ctx.trim(cementBags, 0)} + ${ctx.trim(sandBags, 0)} bags",
            headlineLabel = ctx.str(R.string.f_building_mortar_headline),
            rows = rows,
            notes = notes
        )
    }
}
