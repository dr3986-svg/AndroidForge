package com.diycalculatorpro.calculators.building

import com.diycalculatorpro.R
import com.diycalculatorpro.engine.CalcResult
import com.diycalculatorpro.engine.CalculatorEngine
import com.diycalculatorpro.engine.ChoiceField
import com.diycalculatorpro.engine.ChoiceOption
import com.diycalculatorpro.engine.EngineContext
import com.diycalculatorpro.engine.NumberField
import com.diycalculatorpro.engine.ResultRow
import com.diycalculatorpro.engine.Units
import com.diycalculatorpro.engine.Validate
import com.diycalculatorpro.engine.Values
import kotlin.math.ceil

/**
 * Concrete slab volume, wastage and bagged quantity.
 *
 * Bag yield follows the common site figure of one 20 kg bag yielding roughly
 * 0.0099 m³ of finished concrete.
 */
object ConcreteCalculator : CalculatorEngine {

    const val F_LENGTH = "length"
    const val F_WIDTH = "width"
    const val F_THICKNESS = "thickness"
    const val F_WASTE = "waste"
    const val F_GRADE = "grade"

    const val GRADE_C20 = "c20"
    const val GRADE_C25 = "c25"
    const val GRADE_C30 = "c30"

    /** Yield of one 20 kg bag in m³. */
    private const val BAG_YIELD_M3 = 0.0099

    private val grades = listOf(
        ChoiceOption(GRADE_C20, R.string.opt_grade_c20),
        ChoiceOption(GRADE_C25, R.string.opt_grade_c25),
        ChoiceOption(GRADE_C30, R.string.opt_grade_c30)
    )

    val fields = listOf(
        NumberField(
            id = F_LENGTH,
            labelRes = R.string.f_building_concrete_length,
            unitOptions = listOf(Units.M, Units.MM, Units.CM, Units.FOOT),
            defaultUnitId = Units.M.id,
            allowZero = false
        ),
        NumberField(
            id = F_WIDTH,
            labelRes = R.string.f_building_concrete_width,
            unitOptions = listOf(Units.M, Units.MM, Units.CM, Units.FOOT),
            defaultUnitId = Units.M.id,
            allowZero = false
        ),
        NumberField(
            id = F_THICKNESS,
            labelRes = R.string.f_building_concrete_thickness,
            unitOptions = listOf(Units.MM, Units.CM, Units.M),
            defaultUnitId = Units.MM.id,
            allowZero = false
        ),
        NumberField(
            id = F_WASTE,
            labelRes = R.string.f_building_concrete_waste,
            min = 0.0,
            max = 50.0,
            helperRes = R.string.f_building_concrete_waste_helper
        ),
        ChoiceField(
            id = F_GRADE,
            labelRes = R.string.f_building_concrete_grade,
            options = grades,
            defaultOptionId = GRADE_C25
        )
    )

    private val lengthField = fields.filterIsInstance<NumberField>().first { it.id == F_LENGTH }
    private val widthField = fields.filterIsInstance<NumberField>().first { it.id == F_WIDTH }
    private val thicknessField = fields.filterIsInstance<NumberField>().first { it.id == F_THICKNESS }
    private val wasteField = fields.filterIsInstance<NumberField>().first { it.id == F_WASTE }

    override fun calculate(values: Values, ctx: EngineContext): CalcResult {
        Validate.requireFields(values, listOf(lengthField, widthField, thicknessField))
            ?.let { return it }

        val length = values.baseValue(lengthField) ?: 0.0
        val width = values.baseValue(widthField) ?: 0.0
        val thickness = values.baseValue(thicknessField) ?: 0.0
        if (length <= 0.0) return CalcResult.error(F_LENGTH, Validate.ERR_POSITIVE)
        if (width <= 0.0) return CalcResult.error(F_WIDTH, Validate.ERR_POSITIVE)
        if (thickness <= 0.0) return CalcResult.error(F_THICKNESS, Validate.ERR_POSITIVE)

        val wastePercent = values.numbers[wasteField.id] ?: 5.0
        val area = length * width
        val volume = area * thickness
        val volumeWithWaste = volume * (1.0 + wastePercent / 100.0)
        val bags = ceil(volumeWithWaste / BAG_YIELD_M3)

        val rows = mutableListOf(
            ResultRow(ctx.str(R.string.r_area), ctx.withUnit(area, Units.M2)),
            ResultRow(ctx.str(R.string.r_volume), ctx.withUnit(volume, Units.M3, 3)),
            ResultRow(
                ctx.str(R.string.f_building_concrete_with_waste),
                ctx.withUnit(volumeWithWaste, Units.M3, 3),
                emphasise = true
            ),
            ResultRow(
                ctx.str(R.string.f_building_concrete_bags),
                "${ctx.trim(bags, 0)} bags",
                emphasise = true
            )
        )

        val notes = mutableListOf<String>()
        notes += ctx.str(R.string.f_building_concrete_note_bag)

        return CalcResult(
            headline = ctx.withUnit(volumeWithWaste, Units.M3, 3),
            headlineLabel = ctx.str(R.string.f_building_concrete_headline),
            rows = rows,
            notes = notes
        )
    }
}
