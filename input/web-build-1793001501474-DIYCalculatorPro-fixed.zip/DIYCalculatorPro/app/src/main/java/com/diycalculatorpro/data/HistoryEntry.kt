package com.diycalculatorpro.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * A single saved calculation.
 */
data class HistoryEntry(
    val id: Long,
    val calculatorId: String,
    /** Display title of the calculator, stored so history survives app changes. */
    val calculatorTitle: String,
    val headlineLabel: String,
    val headline: String,
    /** The rows of the result panel, as label/value pairs. */
    val rows: List<Pair<String, String>>,
    val timestamp: Long
) {
    fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put(KEY_ID, id)
        obj.put(KEY_CALCULATOR_ID, calculatorId)
        obj.put(KEY_CALCULATOR_TITLE, calculatorTitle)
        obj.put(KEY_HEADLINE_LABEL, headlineLabel)
        obj.put(KEY_HEADLINE, headline)
        obj.put(KEY_TIMESTAMP, timestamp)
        val rowArray = JSONArray()
        rows.forEach { (label, value) ->
            val row = JSONObject()
            row.put("label", label)
            row.put("value", value)
            rowArray.put(row)
        }
        obj.put(KEY_ROWS, rowArray)
        return obj
    }

    companion object {
        private const val KEY_ID = "id"
        private const val KEY_CALCULATOR_ID = "calculatorId"
        private const val KEY_CALCULATOR_TITLE = "calculatorTitle"
        private const val KEY_HEADLINE_LABEL = "headlineLabel"
        private const val KEY_HEADLINE = "headline"
        private const val KEY_ROWS = "rows"
        private const val KEY_TIMESTAMP = "timestamp"

        fun fromJson(obj: JSONObject): HistoryEntry? {
            return try {
                val rowArray = obj.optJSONArray(KEY_ROWS) ?: JSONArray()
                val rows = (0 until rowArray.length()).mapNotNull { i ->
                    val row = rowArray.optJSONObject(i) ?: return@mapNotNull null
                    row.optString("label") to row.optString("value")
                }
                HistoryEntry(
                    id = obj.optLong(KEY_ID),
                    calculatorId = obj.optString(KEY_CALCULATOR_ID),
                    calculatorTitle = obj.optString(KEY_CALCULATOR_TITLE),
                    headlineLabel = obj.optString(KEY_HEADLINE_LABEL),
                    headline = obj.optString(KEY_HEADLINE),
                    rows = rows,
                    timestamp = obj.optLong(KEY_TIMESTAMP)
                )
            } catch (e: Exception) {
                null
            }
        }
    }
}
