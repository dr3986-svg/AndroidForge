package com.diycalculatorpro.calculators.building

import com.diycalculatorpro.R
import com.diycalculatorpro.engine.CalcResult
import com.diycalculatorpro.engine.CalculatorEngine
import com.diycalculatorpro.engine.EngineContext
import com.diycalculatorpro.engine.NumberField
import com.diycalculatorpro.engine.ResultRow
import com.diycalculatorpro.engine.Units
import com.diycalculatorpro.engine.Validate
import com.diycalculatorpro.engine.Values
import kotlin.math.ceil

/**
 * Generic quantity take-off.
 *
 * Takes an area, a coverage rate per unit and a waste allowance and returns
 * how many units to order. Useful for anything with a "per m²" rate.
 */
object TakeoffCalculator : CalculatorEngine {

    const val F_WIDTH = "width"
    const val F_LENGTH = "length"
    const val F_REPEATS = "repeats"
    const val F_COVERAGE = "coverage"
    const val F_WASTE = "waste"

    val fields = listOf(
        NumberField(
            id = F_WIDTH,
            labelRes = R.string.f_building_takeoff_width,
            unitOptions = listOf(Units.M, Units.MM, Units.CM, Units.FOOT),
            defaultUnitId = Units.M.id,
            allowZero = false
        ),
        NumberField(
            id = F_LENGTH,
            labelRes = R.string.f_building_takeoff_length,
            unitOptions = listOf(Units.M, Units.MM, Units.CM, Units.FOOT),
            defaultUnitId = Units.M.id,
            allowZero = false
        ),
        NumberField(
            id = F_REPEATS,
            labelRes = R.string.f_building_takeoff_repeats,
            min = 1.0,
            max = 10000.0
        ),
        NumberField(
            id = F_COVERAGE,
            labelRes = R.string.f_building_takeoff_coverage,
            min = 0.0001,
            allowZero = false,
            helperRes = R.string.f_building_takeoff_coverage_helper
        ),
        NumberField(
            id = F_WASTE,
            labelRes = R.string.f_building_takeoff_waste,
            min = 0.0,
            max = 50.0
        )
    )

    private val widthField = fields.filterIsInstance<NumberField>().first { it.id == F_WIDTH }
    private val lengthField = fields.filterIsInstance<NumberField>().first { it.id == F_LENGTH }
    private val repeatsField = fields.filterIsInstance<NumberField>().first { it.id == F_REPEATS }
    private val coverageField = fields.filterIsInstance<NumberField>().first { it.id == F_COVERAGE }
    private val wasteField = fields.filterIsInstance<NumberField>().first { it.id == F_WASTE }

    override fun calculate(values: Values, ctx: EngineContext): CalcResult {
        Validate.requireFields(values, listOf(widthField, lengthField, coverageField))
            ?.let { return it }

        val width = values.baseValue(widthField) ?: 0.0
        val length = values.baseValue(lengthField) ?: 0.0
        if (width <= 0.0) return CalcResult.error(F_WIDTH, Validate.ERR_POSITIVE)
        if (length <= 0.0) return CalcResult.error(F_LENGTH, Validate.ERR_POSITIVE)

        val repeats = values.numbers[repeatsField.id] ?: 1.0
        val coverage = values.numbers[coverageField.id] ?: 0.0
        if (coverage <= 0.0) return CalcResult.error(F_COVERAGE, Validate.ERR_POSITIVE)

        val wastePercent = values.numbers[wasteField.id] ?: 0.0

        val area = width * length
        val totalArea = area * repeats
        val unitsBeforeWaste = totalArea / coverage
        val unitsWithWaste = ceil(unitsBeforeWaste * (1.0 + wastePercent / 100.0))
        val perimeter = 2.0 * (width + length) * repeats

        val rows = mutableListOf(
            ResultRow(ctx.str(R.string.r_area), ctx.withUnit(area, Units.M2)),
            ResultRow(ctx.str(R.string.f_building_takeoff_total_area), ctx.withUnit(totalArea, Units.M2)),
            ResultRow(ctx.str(R.string.f_building_takeoff_perimeter), ctx.withUnit(perimeter, Units.M)),
            ResultRow(
                ctx.str(R.string.f_building_takeoff_before_waste),
                ctx.trim(unitsBeforeWaste, 2)
            ),
            ResultRow(
                ctx.str(R.string.f_building_takeoff_after_waste),
                ctx.trim(unitsWithWaste, 0),
                emphasise = true
            )
        )

        return CalcResult(
            headline = ctx.trim(unitsWithWaste, 0),
            headlineLabel = ctx.str(R.string.f_building_takeoff_headline),
            rows = rows
        )
    }
}
