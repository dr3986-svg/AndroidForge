package com.diycalculatorpro.ui.calculator

import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.diycalculatorpro.R
import com.diycalculatorpro.engine.ChoiceField
import com.diycalculatorpro.engine.NumberField
import com.diycalculatorpro.engine.UnitSpec
import com.diycalculatorpro.engine.Values
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

/**
 * Builds the input form for a calculator from its [com.diycalculatorpro.engine.CalculatorSpec]
 * and keeps the current [Values] in sync with what the user types.
 */
class FieldRenderer(
    private val activity: AppCompatActivity,
    private val container: LinearLayout,
    private val spec: com.diycalculatorpro.engine.CalculatorSpec,
    private val onChanged: () -> Unit
) {

    private val numberInputs = mutableMapOf<String, NumberInput>()
    private val choiceInputs = mutableMapOf<String, ChoiceInput>()

    private val numbers = mutableMapOf<String, Double>()
    private val choices = mutableMapOf<String, String>()
    private val units = mutableMapOf<String, String>()

    /** Inflates every field of the calculator into the container. */
    fun build() {
        container.removeAllViews()
        val inflater = LayoutInflater.from(activity)

        spec.fields.forEach { field ->
            when (field) {
                is NumberField -> container.addView(buildNumberField(inflater, field))
                is ChoiceField -> container.addView(buildChoiceField(inflater, field))
            }
        }
    }

    private fun buildNumberField(
        inflater: LayoutInflater,
        field: NumberField
    ): View {
        val view = inflater.inflate(R.layout.item_field_number, container, false)
        val inputLayout = view.findViewById<TextInputLayout>(R.id.field_input_layout)
        val editText = view.findViewById<TextInputEditText>(R.id.field_input)
        val unitButton = view.findViewById<MaterialButton>(R.id.field_unit_button)

        inputLayout.hint = activity.getString(field.labelRes)
        if (field.helperRes != null) {
            inputLayout.helperText = activity.getString(field.helperRes)
        }

        // Unit picker button, only shown when the field actually has units.
        if (field.unitOptions.isNotEmpty()) {
            val defaultUnit = field.unitOptions.firstOrNull { it.id == field.defaultUnitId }
                ?: field.unitOptions.first()
            units[field.id] = defaultUnit.id
            unitButton.text = defaultUnit.label
            unitButton.visibility = View.VISIBLE
            unitButton.setOnClickListener { showUnitPicker(field, defaultUnit) { unit ->
                units[field.id] = unit.id
                unitButton.text = unit.label
                onChanged()
            } }
        } else {
            unitButton.visibility = View.GONE
        }

        editText.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val text = s?.toString().orEmpty().trim()
                if (text.isEmpty()) {
                    numbers.remove(field.id)
                } else {
                    val parsed = parseNumber(text)
                    if (parsed == null) {
                        numbers.remove(field.id)
                    } else {
                        numbers[field.id] = parsed
                    }
                }
                onChanged()
            }
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })

        numberInputs[field.id] = NumberInput(field, inputLayout, editText, unitButton)
        return view
    }

    private fun buildChoiceField(
        inflater: LayoutInflater,
        field: ChoiceField
    ): View {
        val view = inflater.inflate(R.layout.item_field_choice, container, false)
        val label = view.findViewById<android.widget.TextView>(R.id.field_choice_label)
        val button = view.findViewById<MaterialButton>(R.id.field_choice_button)

        label.text = activity.getString(field.labelRes)
        val defaultOption = field.options.firstOrNull { it.id == field.defaultOptionId }
            ?: field.options.first()
        choices[field.id] = defaultOption.id
        button.text = field.labelFor(activity.resources, defaultOption.id)

        button.setOnClickListener {
            val labels = field.options.map { field.labelFor(activity.resources, it.id) }.toTypedArray()
            var selected = choices[field.id] ?: field.defaultOptionId
            MaterialAlertDialogBuilder(activity)
                .setTitle(activity.getString(field.labelRes))
                .setSingleChoiceItems(labels, field.options.indexOfFirst { it.id == selected }) { dialog, which ->
                    val option = field.options[which]
                    selected = option.id
                    choices[field.id] = option.id
                    button.text = field.labelFor(activity.resources, option.id)
                    onChanged()
                    dialog.dismiss()
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }

        choiceInputs[field.id] = ChoiceInput(field, label, button)
        return view
    }

    private fun showUnitPicker(
        field: NumberField,
        current: UnitSpec,
        onPicked: (UnitSpec) -> Unit
    ) {
        val options = field.unitOptions
        val labels = options.map { it.label }.toTypedArray()
        val selectedIndex = options.indexOfFirst { it.id == current.id }.coerceAtLeast(0)
        MaterialAlertDialogBuilder(activity)
            .setTitle(activity.getString(R.string.unit_picker_title))
            .setSingleChoiceItems(labels, selectedIndex) { dialog, which ->
                onPicked(options[which])
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    /** The current state of the form. */
    fun currentValues(): Values = Values(
        numbers = numbers.toMap(),
        choices = choices.toMap(),
        units = units.toMap()
    )

    /** Clears every entered value. */
    fun clear() {
        numbers.clear()
        numberInputs.values.forEach { it.editText.setText("") }
        onChanged()
    }

    /** Highlights the field with an error, or clears all errors when null. */
    fun showError(fieldId: String?, message: String?) {
        numberInputs.values.forEach { input ->
            if (input.field.id == fieldId) {
                input.inputLayout.error = message
            } else {
                input.inputLayout.error = null
            }
        }
    }

    /** The unit currently selected for a field, if any. */
    fun unitFor(fieldId: String): UnitSpec? {
        val input = numberInputs[fieldId] ?: return null
        val selected = units[fieldId] ?: return null
        return input.field.unitOptions.firstOrNull { it.id == selected }
    }

    private class NumberInput(
        val field: NumberField,
        val inputLayout: TextInputLayout,
        val editText: TextInputEditText,
        val unitButton: MaterialButton
    )

    private class ChoiceInput(
        val field: ChoiceField,
        val label: android.widget.TextView,
        val button: MaterialButton
    )

    companion object {
        /**
         * Parses a number the user typed.
         *
         * Accepts a comma as the decimal separator, which is common on site
         * even on devices configured for other locales.
         */
        fun parseNumber(text: String): Double? {
            val cleaned = text.replace(",", ".").trim()
            if (cleaned.isEmpty()) return null
            return cleaned.toDoubleOrNull()
        }
    }
}
