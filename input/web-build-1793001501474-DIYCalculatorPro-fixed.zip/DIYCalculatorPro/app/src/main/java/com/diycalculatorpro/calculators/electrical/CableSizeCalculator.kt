package com.diycalculatorpro.calculators.electrical

import com.diycalculatorpro.R
import com.diycalculatorpro.engine.CalcResult
import com.diycalculatorpro.engine.CalculatorEngine
import com.diycalculatorpro.engine.ChoiceField
import com.diycalculatorpro.engine.ChoiceOption
import com.diycalculatorpro.engine.EngineContext
import com.diycalculatorpro.engine.NumberField
import com.diycalculatorpro.engine.ResultRow
import com.diycalculatorpro.engine.Units
import com.diycalculatorpro.engine.Validate
import com.diycalculatorpro.engine.Values

/**
 * Minimum cable cross-section for a design load.
 *
 * Uses the reference current-carrying capacity of each common installation
 * method, then applies derating for grouping and ambient temperature and
 * rounds up to the next standard size.
 */
object CableSizeCalculator : CalculatorEngine {

    const val F_SYSTEM = "system"
    const val F_LOAD = "load"
    const val F_METHOD = "method"
    const val F_GROUP = "group"
    const val F_AMBIENT = "ambient"

    const val SYS_1PH = "1ph"
    const val SYS_3PH = "3ph"

    /** Reference capacity in A/mm² for each installation method. */
    private val methods = listOf(
        ChoiceOption("a1", R.string.opt_method_a1),
        ChoiceOption("a2", R.string.opt_method_a2),
        ChoiceOption("b1", R.string.opt_method_b1),
        ChoiceOption("b2", R.string.opt_method_b2),
        ChoiceOption("c", R.string.opt_method_c),
        ChoiceOption("d", R.string.opt_method_d),
        ChoiceOption("e", R.string.opt_method_e)
    )

    private val capacityPerMm2 = mapOf(
        "a1" to 4.0,
        "a2" to 5.5,
        "b1" to 11.0,
        "b2" to 14.0,
        "c" to 16.5,
        "d" to 25.0,
        "e" to 32.0
    )

    private val groupingFactor = mapOf(
        "g1" to 1.0,
        "g2" to 0.80,
        "g3" to 0.70,
        "g4" to 0.60
    )

    /** Standard cable sizes in mm². */
    private val standardSizes = listOf(
        1.5, 2.5, 4.0, 6.0, 10.0, 16.0, 25.0, 32.0, 40.0, 50.0, 63.0, 80.0, 100.0, 120.0, 150.0, 185.0, 240.0
    )

    val fields = listOf(
        ChoiceField(
            id = F_SYSTEM,
            labelRes = R.string.f_electrical_cable_system,
            options = listOf(
                ChoiceOption(SYS_1PH, R.string.opt_single_phase),
                ChoiceOption(SYS_3PH, R.string.opt_three_phase)
            ),
            defaultOptionId = SYS_1PH
        ),
        NumberField(
            id = F_LOAD,
            labelRes = R.string.f_electrical_cable_load,
            unitOptions = listOf(Units.AMP),
            defaultUnitId = Units.AMP.id,
            allowZero = false
        ),
        ChoiceField(
            id = F_METHOD,
            labelRes = R.string.f_electrical_cable_method,
            options = methods,
            defaultOptionId = "a1"
        ),
        ChoiceField(
            id = F_GROUP,
            labelRes = R.string.f_electrical_cable_grouping,
            options = listOf(
                ChoiceOption("g1", R.string.opt_group_1),
                ChoiceOption("g2", R.string.opt_group_2),
                ChoiceOption("g3", R.string.opt_group_3),
                ChoiceOption("g4", R.string.opt_group_4)
            ),
            defaultOptionId = "g1"
        ),
        NumberField(
            id = F_AMBIENT,
            labelRes = R.string.f_electrical_cable_ambient,
            unitOptions = listOf(Units.CELSIUS),
            defaultUnitId = Units.CELSIUS.id,
            min = 5.0,
            max = 60.0,
            helperRes = R.string.f_electrical_cable_ambient_helper
        )
    )

    private val loadField = fields.filterIsInstance<NumberField>().first { it.id == F_LOAD }
    private val ambientField = fields.filterIsInstance<NumberField>().first { it.id == F_AMBIENT }

    /** Temperature correction factor relative to 30 °C. */
    private fun temperatureFactor(celsius: Double): Double = when {
        celsius <= 25 -> 1.08
        celsius <= 30 -> 1.00
        celsius <= 35 -> 0.94
        celsius <= 40 -> 0.87
        celsius <= 45 -> 0.79
        celsius <= 50 -> 0.71
        celsius <= 55 -> 0.61
        else -> 0.50
    }

    override fun calculate(values: Values, ctx: EngineContext): CalcResult {
        Validate.requireFields(values, listOf(loadField))?.let { return it }

        val load = values.baseValue(loadField) ?: 0.0
        if (load <= 0.0) {
            return CalcResult.error(F_LOAD, Validate.ERR_POSITIVE)
        }

        val methodId = values.choices[F_METHOD] ?: "a1"
        val groupId = values.choices[F_GROUP] ?: "g1"
        val perMm2 = capacityPerMm2[methodId] ?: 4.0
        val grouping = groupingFactor[groupId] ?: 1.0

        val ambientRaw = values.baseValue(ambientField) ?: 30.0
        val tempFactor = temperatureFactor(ambientRaw)

        val requiredCapacity = load / (grouping * tempFactor)
        val requiredMm2 = requiredCapacity / perMm2
        val selected = standardSizes.firstOrNull { it >= requiredMm2 }
            ?: standardSizes.last()

        val achievable = selected * perMm2 * grouping * tempFactor

        val rows = mutableListOf(
            ResultRow(
                ctx.str(R.string.f_electrical_cable_required_area),
                ctx.withUnit(requiredMm2, Units.MM2),
                emphasise = true
            ),
            ResultRow(ctx.str(R.string.f_electrical_cable_selected_size), "${ctx.trim(selected, 1)} mm²", emphasise = true),
            ResultRow(ctx.str(R.string.f_electrical_cable_capacity), ctx.withUnit(achievable, Units.AMP)),
            ResultRow(ctx.str(R.string.f_electrical_cable_base_capacity), ctx.withUnit(selected * perMm2, Units.AMP)),
            ResultRow(ctx.str(R.string.f_electrical_cable_temp_factor), ctx.trim(tempFactor, 2)),
            ResultRow(ctx.str(R.string.f_electrical_cable_group_factor), ctx.trim(grouping, 2))
        )

        val notes = mutableListOf<String>()
        if (selected == standardSizes.last() && requiredMm2 > selected) {
            notes += ctx.str(R.string.f_electrical_cable_note_large)
        }
        notes += ctx.str(R.string.note_check_local)

        return CalcResult(
            headline = "${ctx.trim(selected, 1)} mm²",
            headlineLabel = ctx.str(R.string.f_electrical_cable_headline),
            rows = rows,
            notes = notes
        )
    }
}
