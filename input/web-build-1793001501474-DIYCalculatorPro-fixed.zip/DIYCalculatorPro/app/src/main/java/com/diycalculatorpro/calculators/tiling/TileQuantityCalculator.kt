package com.diycalculatorpro.calculators.tiling

import com.diycalculatorpro.R
import com.diycalculatorpro.engine.CalcResult
import com.diycalculatorpro.engine.CalculatorEngine
import com.diycalculatorpro.engine.ChoiceField
import com.diycalculatorpro.engine.ChoiceOption
import com.diycalculatorpro.engine.EngineContext
import com.diycalculatorpro.engine.NumberField
import com.diycalculatorpro.engine.ResultRow
import com.diycalculatorpro.engine.Units
import com.diycalculatorpro.engine.Validate
import com.diycalculatorpro.engine.Values
import kotlin.math.ceil

/**
 * Tile quantity for a floor or wall.
 *
 * The grout joint is added to the tile size when working out how many tiles
 * cover the area, because the joint occupies space that the tile does not.
 */
object TileQuantityCalculator : CalculatorEngine {

    const val F_LENGTH = "length"
    const val F_WIDTH = "width"
    const val F_TILE_LENGTH = "tileLength"
    const val F_TILE_WIDTH = "tileWidth"
    const val F_JOINT = "joint"
    const val F_WASTE = "waste"
    const val F_BOXES = "boxes"
    const val F_REPEATS = "repeats"
    const val F_TYPE = "type"

    const val TYPE_CERAMIC = "ceramic"
    const val TYPE_PORCELAIN = "porcelain"
    const val TYPE_LARGE = "large"
    const val TYPE_MOSAIC = "mosaic"

    /** Recommended waste allowance per tile type. */
    private val recommendedWaste = mapOf(
        TYPE_CERAMIC to 10.0,
        TYPE_PORCELAIN to 12.0,
        TYPE_LARGE to 15.0,
        TYPE_MOSAIC to 15.0
    )

    val fields = listOf(
        NumberField(
            id = F_LENGTH,
            labelRes = R.string.f_tiling_quantity_length,
            unitOptions = listOf(Units.M, Units.MM, Units.CM, Units.FOOT),
            defaultUnitId = Units.M.id,
            allowZero = false
        ),
        NumberField(
            id = F_WIDTH,
            labelRes = R.string.f_tiling_quantity_width,
            unitOptions = listOf(Units.M, Units.MM, Units.CM, Units.FOOT),
            defaultUnitId = Units.M.id,
            allowZero = false
        ),
        NumberField(
            id = F_TILE_LENGTH,
            labelRes = R.string.f_tiling_quantity_tile_length,
            unitOptions = listOf(Units.MM, Units.CM, Units.M, Units.INCH),
            defaultUnitId = Units.MM.id,
            allowZero = false
        ),
        NumberField(
            id = F_TILE_WIDTH,
            labelRes = R.string.f_tiling_quantity_tile_width,
            unitOptions = listOf(Units.MM, Units.CM, Units.M, Units.INCH),
            defaultUnitId = Units.MM.id,
            allowZero = false
        ),
        NumberField(
            id = F_JOINT,
            labelRes = R.string.f_tiling_quantity_joint,
            unitOptions = listOf(Units.MM, Units.CM),
            defaultUnitId = Units.MM.id,
            min = 0.0,
            max = 20.0,
            helperRes = R.string.f_tiling_quantity_joint_helper
        ),
        NumberField(
            id = F_WASTE,
            labelRes = R.string.f_tiling_quantity_waste,
            min = 0.0,
            max = 50.0
        ),
        NumberField(
            id = F_BOXES,
            labelRes = R.string.f_tiling_quantity_boxes,
            min = 1.0,
            max = 200.0
        ),
        NumberField(
            id = F_REPEATS,
            labelRes = R.string.f_tiling_quantity_repeats,
            min = 1.0,
            max = 500.0
        ),
        ChoiceField(
            id = F_TYPE,
            labelRes = R.string.f_tiling_quantity_type,
            options = listOf(
                ChoiceOption(TYPE_CERAMIC, R.string.opt_tile_ceramic),
                ChoiceOption(TYPE_PORCELAIN, R.string.opt_tile_porcelain),
                ChoiceOption(TYPE_LARGE, R.string.opt_tile_large),
                ChoiceOption(TYPE_MOSAIC, R.string.opt_tile_mosaic)
            ),
            defaultOptionId = TYPE_CERAMIC
        )
    )

    private val lengthField = fields.filterIsInstance<NumberField>().first { it.id == F_LENGTH }
    private val widthField = fields.filterIsInstance<NumberField>().first { it.id == F_WIDTH }
    private val tileLengthField = fields.filterIsInstance<NumberField>().first { it.id == F_TILE_LENGTH }
    private val tileWidthField = fields.filterIsInstance<NumberField>().first { it.id == F_TILE_WIDTH }
    private val jointField = fields.filterIsInstance<NumberField>().first { it.id == F_JOINT }
    private val wasteField = fields.filterIsInstance<NumberField>().first { it.id == F_WASTE }
    private val boxesField = fields.filterIsInstance<NumberField>().first { it.id == F_BOXES }
    private val repeatsField = fields.filterIsInstance<NumberField>().first { it.id == F_REPEATS }

    override fun calculate(values: Values, ctx: EngineContext): CalcResult {
        Validate.requireFields(values, listOf(lengthField, widthField, tileLengthField, tileWidthField))
            ?.let { return it }

        val length = values.baseValue(lengthField) ?: 0.0
        val width = values.baseValue(widthField) ?: 0.0
        val tileLength = values.baseValue(tileLengthField) ?: 0.0
        val tileWidth = values.baseValue(tileWidthField) ?: 0.0

        if (length <= 0.0) return CalcResult.error(F_LENGTH, Validate.ERR_POSITIVE)
        if (width <= 0.0) return CalcResult.error(F_WIDTH, Validate.ERR_POSITIVE)
        if (tileLength <= 0.0) return CalcResult.error(F_TILE_LENGTH, Validate.ERR_POSITIVE)
        if (tileWidth <= 0.0) return CalcResult.error(F_TILE_WIDTH, Validate.ERR_POSITIVE)

        val joint = values.baseValue(jointField) ?: 0.002
        val type = values.choices[F_TYPE] ?: TYPE_CERAMIC
        val wastePercent = values.numbers[wasteField.id] ?: (recommendedWaste[type] ?: 10.0)
        val tilesPerBox = values.numbers[boxesField.id] ?: 4.0
        val repeats = values.numbers[repeatsField.id] ?: 1.0

        val area = length * width
        val totalArea = area * repeats

        // Effective size of a tile once the joint is included.
        val effectiveLength = tileLength + joint
        val effectiveWidth = tileWidth + joint
        val tileArea = effectiveLength * effectiveWidth

        if (tileArea <= 0.0) return CalcResult.error(F_TILE_LENGTH, Validate.ERR_MATH)

        val tilesExact = totalArea / tileArea
        val tilesWithWaste = ceil(tilesExact * (1.0 + wastePercent / 100.0))
        val boxes = ceil(tilesWithWaste / tilesPerBox)

        val rows = mutableListOf(
            ResultRow(ctx.str(R.string.r_area), ctx.withUnit(area, Units.M2)),
            ResultRow(ctx.str(R.string.f_tiling_quantity_total_area), ctx.withUnit(totalArea, Units.M2)),
            ResultRow(
                ctx.str(R.string.f_tiling_quantity_tiles),
                "${ctx.trim(tilesWithWaste, 0)} tiles",
                emphasise = true
            ),
            ResultRow(
                ctx.str(R.string.f_tiling_quantity_boxes),
                "${ctx.trim(boxes, 0)} boxes",
                emphasise = true
            ),
            ResultRow(ctx.str(R.string.f_tiling_quantity_exact), ctx.trim(tilesExact, 2)),
            ResultRow(ctx.str(R.string.f_tiling_quantity_waste_used), "${ctx.trim(wastePercent, 1)}%")
        )

        val notes = mutableListOf<String>()
        notes += ctx.str(R.string.f_tiling_quantity_note_recommended)
        notes += ctx.str(R.string.note_order_extra)

        return CalcResult(
            headline = "${ctx.trim(tilesWithWaste, 0)} tiles",
            headlineLabel = ctx.str(R.string.f_tiling_quantity_headline),
            rows = rows,
            notes = notes
        )
    }
}
