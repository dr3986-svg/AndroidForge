package com.diycalculatorpro.engine

/**
 * The current state of a calculator form.
 *
 * [numbers] holds raw user entries (in the unit they typed them in),
 * [choices] holds selected option ids and [units] maps a field id to the
 * unit the user picked for it.
 */
data class Values(
    val numbers: Map<String, Double> = emptyMap(),
    val choices: Map<String, String> = emptyMap(),
    val units: Map<String, String> = emptyMap()
) {
    fun number(id: String): Double? = numbers[id]

    fun choice(id: String, fallback: String? = null): String? = choices[id] ?: fallback

    /**
     * Unit currently in force for [field].
     *
     * Only meaningful for fields that declare [NumberField.unitOptions];
     * unitless fields should use [Values.number] directly.
     */
    fun unitFor(field: NumberField): UnitSpec {
        val selected = units[field.id]
        return field.unitOptions.firstOrNull { it.id == selected }
            ?: field.unitOptions.firstOrNull { it.id == field.defaultUnitId }
            ?: field.unitOptions.firstOrNull()
            ?: Units.byId(field.defaultUnitId ?: "")
            ?: Units.NONE
    }

    /** Value converted into the canonical unit of its dimension. */
    fun baseValue(field: NumberField): Double? =
        numbers[field.id]?.let { unitFor(field).toBase(it) }

    /**
     * Value converted into an arbitrary target unit of the same dimension.
     *
     * The raw entry is first taken to the canonical base unit using the unit
     * the user picked, then expressed in [target]. Doing it this way keeps
     * offset scales (°F/°C) correct.
     */
    fun valueIn(field: NumberField, target: UnitSpec): Double? {
        val raw = numbers[field.id] ?: return null
        val base = unitFor(field).toBase(raw)
        return target.fromBase(base)
    }

    fun choiceLabel(res: android.content.res.Resources, field: ChoiceField): String =
        field.labelFor(res, choices[field.id] ?: field.defaultOptionId)

    val isEmpty: Boolean
        get() = numbers.isEmpty() && choices.isEmpty()
}
