package com.diycalculatorpro.calculators.electrical

import com.diycalculatorpro.R
import com.diycalculatorpro.engine.CalcResult
import com.diycalculatorpro.engine.CalculatorEngine
import com.diycalculatorpro.engine.EngineContext
import com.diycalculatorpro.engine.NumberField
import com.diycalculatorpro.engine.ResultRow
import com.diycalculatorpro.engine.Units
import com.diycalculatorpro.engine.Validate
import com.diycalculatorpro.engine.Values
import kotlin.math.sqrt

/**
 * Power and energy for an AC load.
 *
 * Real power = V x I x power factor, so the running current is higher than the
 * simple V x I division once the power factor drops below 1.
 */
object PowerCalculator : CalculatorEngine {

    const val F_LOAD = "load"
    const val F_VOLTAGE = "voltage"
    const val F_PF = "powerFactor"
    const val F_HOURS = "hours"

    val fields = listOf(
        NumberField(
            id = F_LOAD,
            labelRes = R.string.f_electrical_power_load,
            unitOptions = listOf(Units.WATT, Units.KILOWATT, Units.HORSEPOWER),
            defaultUnitId = Units.WATT.id,
            allowZero = false
        ),
        NumberField(
            id = F_VOLTAGE,
            labelRes = R.string.f_electrical_power_voltage,
            unitOptions = listOf(Units.VOLT),
            defaultUnitId = Units.VOLT.id,
            allowZero = false
        ),
        NumberField(
            id = F_PF,
            labelRes = R.string.f_electrical_power_pf,
            min = 0.05,
            max = 1.0,
            helperRes = R.string.f_electrical_power_pf_helper
        ),
        NumberField(
            id = F_HOURS,
            labelRes = R.string.f_electrical_power_hours,
            unitOptions = listOf(Units.HOUR),
            defaultUnitId = Units.HOUR.id,
            min = 0.0,
            helperRes = R.string.f_electrical_power_hours_helper
        )
    )

    private val loadField = fields.filterIsInstance<NumberField>().first { it.id == F_LOAD }
    private val voltageField = fields.filterIsInstance<NumberField>().first { it.id == F_VOLTAGE }
    private val pfField = fields.filterIsInstance<NumberField>().first { it.id == F_PF }
    private val hoursField = fields.filterIsInstance<NumberField>().first { it.id == F_HOURS }

    override fun calculate(values: Values, ctx: EngineContext): CalcResult {
        Validate.requireFields(values, listOf(loadField, voltageField, pfField))
            ?.let { return it }

        val power = values.baseValue(loadField) ?: 0.0
        val voltage = values.baseValue(voltageField) ?: 0.0
        val pf = values.numbers[pfField.id] ?: 1.0
        val hours = values.baseValue(hoursField) ?: 0.0

        if (pf <= 0.0) {
            return CalcResult.error(F_PF, Validate.ERR_POSITIVE)
        }
        if (voltage <= 0.0) {
            return CalcResult.error(F_VOLTAGE, Validate.ERR_POSITIVE)
        }

        val current = power / (voltage * pf)
        if (!current.isFinite()) {
            return CalcResult.error(F_LOAD, Validate.ERR_MATH)
        }

        val apparent = voltage * current
        val reactive = sqrt((apparent * apparent - power * power).coerceAtLeast(0.0))
        val energyPerDay = power * hours
        val energyPerYear = energyPerDay * 365.0

        val rows = mutableListOf(
            ResultRow(
                ctx.str(R.string.f_electrical_power_current),
                ctx.withUnit(current, Units.AMP),
                emphasise = true
            ),
            ResultRow(ctx.str(R.string.f_electrical_power_apparent), ctx.withUnit(apparent, Units.VOLT)),
            ResultRow(ctx.str(R.string.r_power), ctx.withUnit(power, Units.WATT))
        )
        if (reactive > 0.0) {
            rows += ResultRow(ctx.str(R.string.f_electrical_power_reactive), ctx.withUnit(reactive, Units.VOLT))
        }
        rows += ResultRow(ctx.str(R.string.f_electrical_power_energy_day), ctx.withUnit(energyPerDay, Units.KILOWATT_HOUR))
        rows += ResultRow(ctx.str(R.string.f_electrical_power_energy_year), ctx.withUnit(energyPerYear, Units.KILOWATT_HOUR))

        return CalcResult(
            headline = ctx.withUnit(current, Units.AMP),
            headlineLabel = ctx.str(R.string.f_electrical_power_current),
            rows = rows
        )
    }
}
