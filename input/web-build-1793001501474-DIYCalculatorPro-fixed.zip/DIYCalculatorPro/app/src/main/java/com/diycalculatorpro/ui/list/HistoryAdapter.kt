package com.diycalculatorpro.ui.list

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.diycalculatorpro.R
import com.diycalculatorpro.data.HistoryEntry
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Adapter for the calculation history.
 */
class HistoryAdapter(
    private val onClick: (HistoryEntry) -> Unit,
    private val onDelete: (HistoryEntry) -> Unit
) : RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {

    private val items = mutableListOf<HistoryEntry>()

    fun submit(entries: List<HistoryEntry>) {
        items.clear()
        items.addAll(entries)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_history, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val title: TextView = itemView.findViewById(R.id.history_title)
        private val label: TextView = itemView.findViewById(R.id.history_label)
        private val value: TextView = itemView.findViewById(R.id.history_value)
        private val detail: TextView = itemView.findViewById(R.id.history_detail)
        private val timestamp: TextView = itemView.findViewById(R.id.history_timestamp)
        private val delete: ImageButton = itemView.findViewById(R.id.delete_button)

        fun bind(entry: HistoryEntry) {
            val context = itemView.context
            title.text = entry.calculatorTitle
            label.text = entry.headlineLabel
            value.text = entry.headline

            val detailText = entry.rows.joinToString("  ·  ") { "${it.first}: ${it.second}" }
            detail.text = detailText
            detail.visibility = if (detailText.isBlank()) View.GONE else View.VISIBLE

            timestamp.text = DATE_FORMAT.format(Date(entry.timestamp))

            delete.setOnClickListener { onDelete(entry) }
            itemView.setOnClickListener { onClick(entry) }
        }
    }

    companion object {
        private val DATE_FORMAT = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault())
    }
}
