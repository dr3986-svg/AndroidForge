package com.diycalculatorpro.calculators.painting

import com.diycalculatorpro.R
import com.diycalculatorpro.engine.CalcResult
import com.diycalculatorpro.engine.CalculatorEngine
import com.diycalculatorpro.engine.ChoiceField
import com.diycalculatorpro.engine.ChoiceOption
import com.diycalculatorpro.engine.EngineContext
import com.diycalculatorpro.engine.NumberField
import com.diycalculatorpro.engine.ResultRow
import com.diycalculatorpro.engine.Units
import com.diycalculatorpro.engine.Validate
import com.diycalculatorpro.engine.Values

/**
 * Wall and ceiling area for a rectangular room.
 *
 * Doors and windows are deducted from the wall area so the paint figure
 * reflects what actually gets painted.
 */
object RoomWallsCalculator : CalculatorEngine {

    const val F_LENGTH = "length"
    const val F_WIDTH = "width"
    const val F_HEIGHT = "height"
    const val F_DOORS = "doors"
    const val F_WINDOWS = "windows"
    const val F_DOOR_AREA = "doorArea"
    const val F_WINDOW_AREA = "windowArea"
    const val F_CEILING = "ceiling"

    const val CEILING_YES = "yes"
    const val CEILING_NO = "no"

    val fields = listOf(
        NumberField(
            id = F_LENGTH,
            labelRes = R.string.f_painting_walls_length,
            unitOptions = listOf(Units.M, Units.MM, Units.CM, Units.FOOT),
            defaultUnitId = Units.M.id,
            allowZero = false
        ),
        NumberField(
            id = F_WIDTH,
            labelRes = R.string.f_painting_walls_width,
            unitOptions = listOf(Units.M, Units.MM, Units.CM, Units.FOOT),
            defaultUnitId = Units.M.id,
            allowZero = false
        ),
        NumberField(
            id = F_HEIGHT,
            labelRes = R.string.f_painting_walls_height,
            unitOptions = listOf(Units.M, Units.MM, Units.CM, Units.FOOT),
            defaultUnitId = Units.M.id,
            allowZero = false
        ),
        NumberField(
            id = F_DOORS,
            labelRes = R.string.f_painting_walls_doors,
            min = 0.0,
            max = 100.0
        ),
        NumberField(
            id = F_WINDOWS,
            labelRes = R.string.f_painting_walls_windows,
            min = 0.0,
            max = 200.0
        ),
        NumberField(
            id = F_DOOR_AREA,
            labelRes = R.string.f_painting_walls_door_area,
            unitOptions = listOf(Units.M2, Units.FT2),
            defaultUnitId = Units.M2.id,
            min = 0.0,
            helperRes = R.string.f_painting_walls_door_area_helper
        ),
        NumberField(
            id = F_WINDOW_AREA,
            labelRes = R.string.f_painting_walls_window_area,
            unitOptions = listOf(Units.M2, Units.FT2),
            defaultUnitId = Units.M2.id,
            min = 0.0,
            helperRes = R.string.f_painting_walls_window_area_helper
        ),
        ChoiceField(
            id = F_CEILING,
            labelRes = R.string.f_painting_walls_ceiling,
            options = listOf(
                ChoiceOption(CEILING_YES, R.string.opt_yes),
                ChoiceOption(CEILING_NO, R.string.opt_no)
            ),
            defaultOptionId = CEILING_YES
        )
    )

    private val lengthField = fields.filterIsInstance<NumberField>().first { it.id == F_LENGTH }
    private val widthField = fields.filterIsInstance<NumberField>().first { it.id == F_WIDTH }
    private val heightField = fields.filterIsInstance<NumberField>().first { it.id == F_HEIGHT }
    private val doorsField = fields.filterIsInstance<NumberField>().first { it.id == F_DOORS }
    private val windowsField = fields.filterIsInstance<NumberField>().first { it.id == F_WINDOWS }
    private val doorAreaField = fields.filterIsInstance<NumberField>().first { it.id == F_DOOR_AREA }
    private val windowAreaField = fields.filterIsInstance<NumberField>().first { it.id == F_WINDOW_AREA }

    override fun calculate(values: Values, ctx: EngineContext): CalcResult {
        Validate.requireFields(values, listOf(lengthField, widthField, heightField))?.let { return it }

        val length = values.baseValue(lengthField) ?: 0.0
        val width = values.baseValue(widthField) ?: 0.0
        val height = values.baseValue(heightField) ?: 0.0
        if (length <= 0.0) return CalcResult.error(F_LENGTH, Validate.ERR_POSITIVE)
        if (width <= 0.0) return CalcResult.error(F_WIDTH, Validate.ERR_POSITIVE)
        if (height <= 0.0) return CalcResult.error(F_HEIGHT, Validate.ERR_POSITIVE)

        val doors = values.numbers[doorsField.id] ?: 0.0
        val windows = values.numbers[windowsField.id] ?: 0.0
        val doorArea = values.baseValue(doorAreaField) ?: 1.8
        val windowArea = values.baseValue(windowAreaField) ?: 1.2
        val includeCeiling = (values.choices[F_CEILING] ?: CEILING_YES) == CEILING_YES

        val perimeter = 2.0 * (length + width)
        val grossWallArea = perimeter * height
        val openings = doors * doorArea + windows * windowArea
        val netWallArea = (grossWallArea - openings).coerceAtLeast(0.0)
        val ceilingArea = if (includeCeiling) length * width else 0.0
        val totalArea = netWallArea + ceilingArea

        val rows = mutableListOf(
            ResultRow(ctx.str(R.string.r_perimeter), ctx.withUnit(perimeter, Units.M)),
            ResultRow(ctx.str(R.string.f_painting_walls_gross), ctx.withUnit(grossWallArea, Units.M2)),
            ResultRow(ctx.str(R.string.f_painting_walls_openings), ctx.withUnit(openings, Units.M2)),
            ResultRow(
                ctx.str(R.string.f_painting_walls_net),
                ctx.withUnit(netWallArea, Units.M2),
                emphasise = true
            ),
            ResultRow(
                ctx.str(R.string.f_painting_walls_ceiling_area),
                ctx.withUnit(ceilingArea, Units.M2),
                emphasise = includeCeiling
            ),
            ResultRow(
                ctx.str(R.string.r_total),
                ctx.withUnit(totalArea, Units.M2),
                emphasise = true
            )
        )

        val notes = mutableListOf<String>()
        notes += ctx.str(R.string.f_painting_walls_note_estimate)

        return CalcResult(
            headline = ctx.withUnit(totalArea, Units.M2),
            headlineLabel = ctx.str(R.string.f_painting_walls_total_area),
            rows = rows,
            notes = notes
        )
    }
}
