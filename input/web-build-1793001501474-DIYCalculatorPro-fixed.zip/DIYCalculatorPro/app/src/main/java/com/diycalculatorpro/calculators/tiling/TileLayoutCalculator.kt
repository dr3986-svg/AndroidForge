package com.diycalculatorpro.calculators.tiling

import com.diycalculatorpro.R
import com.diycalculatorpro.engine.CalcResult
import com.diycalculatorpro.engine.CalculatorEngine
import com.diycalculatorpro.engine.ChoiceField
import com.diycalculatorpro.engine.ChoiceOption
import com.diycalculatorpro.engine.EngineContext
import com.diycalculatorpro.engine.NumberField
import com.diycalculatorpro.engine.ResultRow
import com.diycalculatorpro.engine.Units
import com.diycalculatorpro.engine.Validate
import com.diycalculatorpro.engine.Values
import kotlin.math.ceil
import kotlin.math.floor

/**
 * Tile layout, cut pieces and pattern waste.
 *
 * Works out how many tiles fit across the room, how many are cut at the edges
 * and what waste the chosen pattern creates.
 */
object TileLayoutCalculator : CalculatorEngine {

    const val F_LENGTH = "length"
    const val F_WIDTH = "width"
    const val F_TILE_LENGTH = "tileLength"
    const val F_TILE_WIDTH = "tileWidth"
    const val F_JOINT = "joint"
    const val F_PATTERN = "pattern"

    const val PATTERN_STACK = "stack"
    const val PATTERN_BOND = "bond"
    const val PATTERN_DIAGONAL = "diagonal"
    const val PATTERN_HERRINGBONE = "herringbone"

    /** Additional waste percentage for each pattern. */
    private val patternWaste = mapOf(
        PATTERN_STACK to 10.0,
        PATTERN_BOND to 12.0,
        PATTERN_DIAGONAL to 20.0,
        PATTERN_HERRINGBONE to 25.0
    )

    val fields = listOf(
        NumberField(
            id = F_LENGTH,
            labelRes = R.string.f_tiling_layout_length,
            unitOptions = listOf(Units.M, Units.MM, Units.CM, Units.FOOT),
            defaultUnitId = Units.M.id,
            allowZero = false
        ),
        NumberField(
            id = F_WIDTH,
            labelRes = R.string.f_tiling_layout_width,
            unitOptions = listOf(Units.M, Units.MM, Units.CM, Units.FOOT),
            defaultUnitId = Units.M.id,
            allowZero = false
        ),
        NumberField(
            id = F_TILE_LENGTH,
            labelRes = R.string.f_tiling_layout_tile_length,
            unitOptions = listOf(Units.MM, Units.CM, Units.M, Units.INCH),
            defaultUnitId = Units.MM.id,
            allowZero = false
        ),
        NumberField(
            id = F_TILE_WIDTH,
            labelRes = R.string.f_tiling_layout_tile_width,
            unitOptions = listOf(Units.MM, Units.CM, Units.M, Units.INCH),
            defaultUnitId = Units.MM.id,
            allowZero = false
        ),
        NumberField(
            id = F_JOINT,
            labelRes = R.string.f_tiling_layout_joint,
            unitOptions = listOf(Units.MM, Units.CM),
            defaultUnitId = Units.MM.id,
            min = 0.0,
            max = 20.0
        ),
        ChoiceField(
            id = F_PATTERN,
            labelRes = R.string.f_tiling_layout_pattern,
            options = listOf(
                ChoiceOption(PATTERN_STACK, R.string.opt_pattern_stack),
                ChoiceOption(PATTERN_BOND, R.string.opt_pattern_bond),
                ChoiceOption(PATTERN_DIAGONAL, R.string.opt_pattern_diagonal),
                ChoiceOption(PATTERN_HERRINGBONE, R.string.opt_pattern_herringbone)
            ),
            defaultOptionId = PATTERN_STACK
        )
    )

    private val lengthField = fields.filterIsInstance<NumberField>().first { it.id == F_LENGTH }
    private val widthField = fields.filterIsInstance<NumberField>().first { it.id == F_WIDTH }
    private val tileLengthField = fields.filterIsInstance<NumberField>().first { it.id == F_TILE_LENGTH }
    private val tileWidthField = fields.filterIsInstance<NumberField>().first { it.id == F_TILE_WIDTH }
    private val jointField = fields.filterIsInstance<NumberField>().first { it.id == F_JOINT }

    override fun calculate(values: Values, ctx: EngineContext): CalcResult {
        Validate.requireFields(values, listOf(lengthField, widthField, tileLengthField, tileWidthField))
            ?.let { return it }

        val length = values.baseValue(lengthField) ?: 0.0
        val width = values.baseValue(widthField) ?: 0.0
        val tileLength = values.baseValue(tileLengthField) ?: 0.0
        val tileWidth = values.baseValue(tileWidthField) ?: 0.0

        if (length <= 0.0) return CalcResult.error(F_LENGTH, Validate.ERR_POSITIVE)
        if (width <= 0.0) return CalcResult.error(F_WIDTH, Validate.ERR_POSITIVE)
        if (tileLength <= 0.0) return CalcResult.error(F_TILE_LENGTH, Validate.ERR_POSITIVE)
        if (tileWidth <= 0.0) return CalcResult.error(F_TILE_WIDTH, Validate.ERR_POSITIVE)

        val joint = values.baseValue(jointField) ?: 0.002
        val pattern = values.choices[F_PATTERN] ?: PATTERN_STACK
        val wastePercent = patternWaste[pattern] ?: 10.0

        val stepLength = tileLength + joint
        val stepWidth = tileWidth + joint

        // Tiles across the room, allowing for a cut at each end.
        val tilesAcross = ceil(length / stepLength).toInt()
        val tilesDown = ceil(width / stepWidth).toInt()
        val cutAcross = length - (tilesAcross - 1) * stepLength
        val cutDown = width - (tilesDown - 1) * stepWidth

        val fullTiles = (tilesAcross - 1) * (tilesDown - 1)
        val cutTiles = (tilesAcross - 1) + (tilesDown - 1)
        val cornerTiles = 1

        val baseTiles = fullTiles + cutTiles + cornerTiles
        val totalTiles = ceil(baseTiles * (1.0 + wastePercent / 100.0)).toInt()

        val rows = mutableListOf(
            ResultRow(
                ctx.str(R.string.f_tiling_layout_tiles_across),
                "$tilesAcross × $tilesDown",
                emphasise = true
            ),
            ResultRow(ctx.str(R.string.f_tiling_layout_full_tiles), "$fullTiles"),
            ResultRow(ctx.str(R.string.f_tiling_layout_cut_tiles), "$cutTiles"),
            ResultRow(
                ctx.str(R.string.f_tiling_layout_cut_width),
                "${ctx.trim(cutAcross * 1000.0, 0)} mm",
                emphasise = true
            ),
            ResultRow(
                ctx.str(R.string.f_tiling_layout_cut_depth),
                "${ctx.trim(cutDown * 1000.0, 0)} mm",
                emphasise = true
            ),
            ResultRow(
                ctx.str(R.string.f_tiling_layout_total),
                "$totalTiles tiles",
                emphasise = true
            ),
            ResultRow(ctx.str(R.string.f_tiling_layout_waste), "${ctx.trim(wastePercent, 0)}%")
        )

        val notes = mutableListOf<String>()
        if (cutAcross < tileLength * 0.5) {
            notes += ctx.str(R.string.f_tiling_layout_note_narrow_cut)
        }
        notes += ctx.str(R.string.f_tiling_layout_note_center)
        notes += ctx.str(R.string.note_order_extra)

        return CalcResult(
            headline = "$totalTiles tiles",
            headlineLabel = ctx.str(R.string.f_tiling_layout_headline),
            rows = rows,
            notes = notes
        )
    }
}
